#!/usr/bin/env bash
# Prepares the generated Android project: app name + internet permission.
# Run by the GitHub Actions workflow (from the project folder) after "flutter create".
set -e
MANIFEST="android/app/src/main/AndroidManifest.xml"

# App name shown under the launcher icon
sed -i 's/android:label="[^"]*"/android:label="Khmer Shopping"/' "$MANIFEST"

# Internet permission is needed to load product pictures in the release APK
if ! grep -q "android.permission.INTERNET" "$MANIFEST"; then
  sed -i 's|<application|<uses-permission android:name="android.permission.INTERNET"/>\n    <application|' "$MANIFEST"
fi

grep -n "INTERNET\|android:label" "$MANIFEST"
