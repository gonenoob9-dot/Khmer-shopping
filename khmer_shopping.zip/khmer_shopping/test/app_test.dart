import 'package:flutter_test/flutter_test.dart';

import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/data/sample_data.dart';

void main() {
  group('formatPrice', () {
    test('formats small and large amounts', () {
      expect(formatPrice(0), '\$0.00');
      expect(formatPrice(129), '\$129.00');
      expect(formatPrice(1249.5), '\$1,249.50');
      expect(formatPrice(1000000), '\$1,000,000.00');
    });
  });

  group('SampleData', () {
    test('has unique product ids', () {
      final ids = SampleData.products.map((p) => p.id).toSet();
      expect(ids.length, SampleData.products.length);
    });

    test('every product belongs to a known category', () {
      final names = SampleData.categories.map((c) => c.name).toSet();
      for (final product in SampleData.products) {
        expect(names.contains(product.category), isTrue, reason: product.id);
      }
    });

    test('discounted price is computed correctly', () {
      final headphones = SampleData.byId('e1')!;
      expect(headphones.finalPrice, 96.75);
      expect(SampleData.byId('e4')!.finalPrice, 59);
    });
  });
}
