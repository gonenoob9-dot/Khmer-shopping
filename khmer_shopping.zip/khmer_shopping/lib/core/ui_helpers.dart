import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/theme.dart';

/// Shows a floating snackbar using the nearest ScaffoldMessenger.
void showAppSnack(
  BuildContext context,
  String message, {
  String? actionLabel,
  VoidCallback? onAction,
  IconData icon = Icons.check_circle,
}) {
  showSnackOn(
    ScaffoldMessenger.of(context),
    message,
    actionLabel: actionLabel,
    onAction: onAction,
    icon: icon,
  );
}

/// Same as [showAppSnack] but takes an already-captured messenger. Use this
/// when the originating widget may be removed before the snackbar is shown.
void showSnackOn(
  ScaffoldMessengerState messenger,
  String message, {
  String? actionLabel,
  VoidCallback? onAction,
  IconData icon = Icons.check_circle,
}) {
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        duration: Duration(seconds: 3),
        content: Row(
          children: [
            Icon(icon, color: AppColors.gold, size: 20),
            SizedBox(width: 10),
            Expanded(
              child: Text(message, maxLines: 2, overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
        action: actionLabel == null
            ? null
            : SnackBarAction(
                label: actionLabel,
                onPressed: onAction ?? () {},
              ),
      ),
    );
}

/// Simple yes/no confirmation dialog.
Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  String confirmLabel = 'Confirm',
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: Text(title),
      content: Text(message),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(false),
          child: Text('Cancel'),
        ),
        FilledButton(
          style: FilledButton.styleFrom(minimumSize: Size(96, 44)),
          onPressed: () => Navigator.of(dialogContext).pop(true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result ?? false;
}

/// Height of a product card for a given card width. Grows with text scale so
/// text never overflows on devices with large fonts.
double productCardHeight(BuildContext context, double cardWidth) {
  final scaler = MediaQuery.textScalerOf(context);
  return cardWidth * 0.78 + scaler.scale(106);
}

/// Responsive 2/3/4 column grid delegate for product cards.
SliverGridDelegate productGridDelegate(
  BuildContext context, {
  double horizontalPadding = 16,
}) {
  final available = MediaQuery.sizeOf(context).width - horizontalPadding * 2;
  final columns = available >= 840
      ? 4
      : available >= 560
          ? 3
          : 2;
  const spacing = 12.0;
  final cardWidth = (available - spacing * (columns - 1)) / columns;
  return SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: columns,
    mainAxisSpacing: spacing,
    crossAxisSpacing: spacing,
    mainAxisExtent: productCardHeight(context, cardWidth),
  );
}
