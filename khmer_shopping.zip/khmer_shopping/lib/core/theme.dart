import 'package:flutter/material.dart';

/// App colour palette. Most colours change with [isLight], so they are getters.
/// `black` is the app background colour (near-black in dark mode, warm
/// off-white in light mode). Use [onGold] for text/icons placed on gold.
class AppColors {
  AppColors._();

  /// Set by the theme provider before the UI is built.
  static bool isLight = false;

  // ---- Surfaces ----
  static Color get black =>
      isLight ? const Color(0xFFF4F0E6) : const Color(0xFF0A0A0A);
  static Color get surface =>
      isLight ? const Color(0xFFFFFFFF) : const Color(0xFF141414);
  static Color get card =>
      isLight ? const Color(0xFFFFFFFF) : const Color(0xFF1C1C1C);
  static Color get cardLight =>
      isLight ? const Color(0xFFEBE4D2) : const Color(0xFF2A2A2A);

  // ---- Text ----
  static Color get textPrimary =>
      isLight ? const Color(0xFF1B1B1B) : const Color(0xFFF5F5F5);
  static Color get textSecondary =>
      isLight ? const Color(0xFF6A6558) : const Color(0xFFA8A8A8);

  // ---- Gold ----
  /// Gold for text and icons (darker in light mode for contrast).
  static Color get gold =>
      isLight ? const Color(0xFF9A7208) : const Color(0xFFD4AF37);

  /// Bright gold for filled surfaces (chips, dots, buttons).
  static const Color goldFill = Color(0xFFD4AF37);
  static const Color goldLight = Color(0xFFF2D675);
  static const Color goldDark = Color(0xFF9C7A1A);

  /// Foreground colour for text and icons placed on gold.
  static const Color onGold = Color(0xFF1A1405);

  static LinearGradient get goldGradient => LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: isLight
            ? const [Color(0xFFF3D46B), Color(0xFFDCB236), Color(0xFFB88A12)]
            : const [Color(0xFFF2D675), Color(0xFFD4AF37), Color(0xFF9C7A1A)],
      );

  // ---- Status ----
  static const Color danger = Color(0xFFE5484D);
  static Color get success =>
      isLight ? const Color(0xFF1F9D3A) : const Color(0xFF3FB950);

  // ---- Misc ----
  /// Hairline borders and dividers.
  static Color get line =>
      isLight ? const Color(0x1A000000) : const Color(0x14FFFFFF);

  /// Start colour of the profile hero card gradient.
  static Color get heroStart =>
      isLight ? const Color(0xFFFBF0CC) : const Color(0xFF2E260C);

  /// End colour of product artwork gradients.
  static Color get artEnd =>
      isLight ? const Color(0xFFEFE8D6) : const Color(0xFF0E0E0E);

  /// Adapts a dark category tint to the current mode.
  static Color artTint(Color dark) =>
      isLight ? Color.lerp(dark, Colors.white, 0.86)! : dark;

  /// Soft shadow used by cards in light mode (none in dark mode).
  static List<BoxShadow> get cardShadow => isLight
      ? const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 14,
            offset: Offset(0, 4),
          ),
        ]
      : const [];
}

class AppTheme {
  AppTheme._();

  static ThemeData build(bool light) {
    AppColors.isLight = light;
    final brightness = light ? Brightness.light : Brightness.dark;

    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.goldFill,
      brightness: brightness,
    ).copyWith(
      primary: AppColors.gold,
      onPrimary: light ? Colors.white : AppColors.onGold,
      secondary: AppColors.goldLight,
      onSecondary: AppColors.onGold,
      surface: AppColors.surface,
      onSurface: AppColors.textPrimary,
      surfaceContainerHigh: AppColors.card,
      error: AppColors.danger,
    );

    final inputBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(14),
      borderSide: BorderSide(
        color: light ? const Color(0x22000000) : const Color(0x0FFFFFFF),
      ),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: AppColors.black,
      splashFactory: InkRipple.splashFactory,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.black,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: AppColors.surface,
        indicatorColor: AppColors.goldFill.withValues(alpha: 0.25),
        height: 68,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return TextStyle(
            fontSize: 12,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? AppColors.gold : AppColors.textSecondary,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(
            color: selected ? AppColors.gold : AppColors.textSecondary,
          );
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.card,
        hintStyle: TextStyle(color: AppColors.textSecondary),
        labelStyle: TextStyle(color: AppColors.textSecondary),
        prefixIconColor: AppColors.textSecondary,
        suffixIconColor: AppColors.textSecondary,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: inputBorder,
        enabledBorder: inputBorder,
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: AppColors.gold, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.danger),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.danger, width: 1.6),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.goldFill,
          foregroundColor: AppColors.onGold,
          minimumSize: const Size(0, 52),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.gold,
          minimumSize: const Size(0, 52),
          side: BorderSide(color: AppColors.gold, width: 1.4),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle:
              const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: AppColors.gold),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF2A2A2A),
        contentTextStyle: const TextStyle(color: Color(0xFFF5F5F5)),
        actionTextColor: AppColors.goldLight,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? AppColors.onGold
                : (light ? Colors.white : AppColors.textSecondary)),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? AppColors.goldFill
                : (light ? const Color(0xFFCFC7B2) : AppColors.cardLight)),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      dividerTheme: DividerThemeData(
        color: AppColors.line,
        thickness: 1,
        space: 1,
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: AppColors.goldFill,
        linearTrackColor: AppColors.cardLight,
      ),
    );
  }
}
