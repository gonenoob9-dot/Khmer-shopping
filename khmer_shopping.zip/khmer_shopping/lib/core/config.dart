class AppConfig {
  AppConfig._();

  static const String appName = 'Khmer Shopping';
  static const String version = '1.0.0';

  /// Orders at or above this subtotal get free delivery.
  static const double freeDeliveryThreshold = 100.0;

  /// Flat delivery fee for orders below the threshold.
  static const double deliveryCharge = 3.0;

  static const int maxQuantity = 99;
  static const int maxRecentSearches = 8;
}
