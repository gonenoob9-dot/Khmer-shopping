import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/providers/nav_provider.dart';

/// Indexes of the bottom navigation tabs.
class AppTabs {
  AppTabs._();

  static const int home = 0;
  static const int search = 1;
  static const int wishlist = 2;
  static const int cart = 3;
  static const int profile = 4;
}

/// Global navigation helper so any widget (or snackbar action) can jump to a tab.
class AppNavigator {
  AppNavigator._();

  static final GlobalKey<NavigatorState> key = GlobalKey<NavigatorState>();

  static void goToTab(int index) {
    final navigator = key.currentState;
    final context = key.currentContext;
    if (navigator == null || context == null) return;
    navigator.popUntil((route) => route.isFirst);
    Provider.of<NavProvider>(context, listen: false).setIndex(index);
  }

  static Future<T?>? push<T>(Route<T> route) => key.currentState?.push<T>(route);
}
