import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/cart_item.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/services/storage_service.dart';

class CartProvider extends ChangeNotifier {
  CartProvider(this._storage) {
    _storage.readCart().forEach((id, qty) {
      if (SampleData.byId(id) != null && qty > 0) {
        _quantities[id] = math.min(qty, AppConfig.maxQuantity);
      }
    });
  }

  final StorageService _storage;
  final Map<String, int> _quantities = {};

  List<CartItem> get items => _quantities.entries
      .map((e) => CartItem(product: SampleData.byId(e.key)!, quantity: e.value))
      .toList();

  bool get isEmpty => _quantities.isEmpty;

  int get itemCount => _quantities.values.fold(0, (sum, q) => sum + q);

  int quantityOf(String productId) => _quantities[productId] ?? 0;

  double get subtotal => roundMoney(
        items.fold<double>(0, (sum, item) => sum + item.lineTotal),
      );

  double get deliveryFee {
    if (_quantities.isEmpty) return 0;
    return subtotal >= AppConfig.freeDeliveryThreshold
        ? 0
        : AppConfig.deliveryCharge;
  }

  double get total => roundMoney(subtotal + deliveryFee);

  void add(Product product, {int quantity = 1}) {
    final current = _quantities[product.id] ?? 0;
    _quantities[product.id] =
        math.max(1, math.min(current + quantity, AppConfig.maxQuantity));
    _changed();
  }

  void increment(String productId) {
    final current = _quantities[productId];
    if (current == null || current >= AppConfig.maxQuantity) return;
    _quantities[productId] = current + 1;
    _changed();
  }

  void decrement(String productId) {
    final current = _quantities[productId];
    if (current == null || current <= 1) return;
    _quantities[productId] = current - 1;
    _changed();
  }

  void remove(String productId) {
    if (_quantities.remove(productId) != null) _changed();
  }

  void clear() {
    if (_quantities.isEmpty) return;
    _quantities.clear();
    _changed();
  }

  void _changed() {
    _storage.writeCart(_quantities);
    notifyListeners();
  }
}
