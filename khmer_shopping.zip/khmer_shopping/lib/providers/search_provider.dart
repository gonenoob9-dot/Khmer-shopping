import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/product.dart';

enum SortOption { relevance, priceLowToHigh, priceHighToLow }

/// Holds the search query, category filter and sort order. Shared between the
/// Home screen (category shortcuts, banners) and the Search tab.
class SearchProvider extends ChangeNotifier {
  String _query = '';
  String? _category;
  SortOption _sort = SortOption.relevance;
  bool _focusRequested = false;

  String get query => _query;
  String? get category => _category;
  SortOption get sort => _sort;
  bool get hasFilters => _query.trim().isNotEmpty || _category != null;

  /// True once after [requestFocus]; the Search screen consumes it.
  bool consumeFocusRequest() {
    final value = _focusRequested;
    _focusRequested = false;
    return value;
  }

  bool get focusRequested => _focusRequested;

  List<Product> get results {
    final q = _query.trim().toLowerCase();
    final list = SampleData.products.where((p) {
      final matchesCategory = _category == null || p.category == _category;
      final matchesQuery = q.isEmpty ||
          p.name.toLowerCase().contains(q) ||
          p.category.toLowerCase().contains(q);
      return matchesCategory && matchesQuery;
    }).toList();

    switch (_sort) {
      case SortOption.priceLowToHigh:
        list.sort((a, b) => a.finalPrice.compareTo(b.finalPrice));
      case SortOption.priceHighToLow:
        list.sort((a, b) => b.finalPrice.compareTo(a.finalPrice));
      case SortOption.relevance:
        break;
    }
    return list;
  }

  void setQuery(String value) {
    if (value == _query) return;
    _query = value;
    notifyListeners();
  }

  void setCategory(String? value) {
    _category = value;
    notifyListeners();
  }

  void setSort(SortOption value) {
    _sort = value;
    notifyListeners();
  }

  void clearAll() {
    _query = '';
    _category = null;
    _sort = SortOption.relevance;
    notifyListeners();
  }

  void requestFocus() {
    _focusRequested = true;
    notifyListeners();
  }
}
