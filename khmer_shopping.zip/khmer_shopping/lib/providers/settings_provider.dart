import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/services/storage_service.dart';

class SettingsProvider extends ChangeNotifier {
  SettingsProvider(this._storage)
      : _notifications = _storage.readNotifications(),
        _recentSearches = List<String>.from(_storage.readRecentSearches());

  final StorageService _storage;
  bool _notifications;
  final List<String> _recentSearches;

  bool get notifications => _notifications;

  List<String> get recentSearches => List.unmodifiable(_recentSearches);

  void setNotifications(bool value) {
    _notifications = value;
    _storage.writeNotifications(value);
    notifyListeners();
  }

  void addRecentSearch(String query) {
    final value = query.trim();
    if (value.isEmpty) return;
    _recentSearches.removeWhere((e) => e.toLowerCase() == value.toLowerCase());
    _recentSearches.insert(0, value);
    if (_recentSearches.length > AppConfig.maxRecentSearches) {
      _recentSearches.removeRange(
        AppConfig.maxRecentSearches,
        _recentSearches.length,
      );
    }
    _storage.writeRecentSearches(_recentSearches);
    notifyListeners();
  }

  void clearRecentSearches() {
    if (_recentSearches.isEmpty) return;
    _recentSearches.clear();
    _storage.writeRecentSearches(_recentSearches);
    notifyListeners();
  }

  void reset() {
    _notifications = true;
    _recentSearches.clear();
    _storage.writeNotifications(true);
    _storage.writeRecentSearches(_recentSearches);
    notifyListeners();
  }
}
