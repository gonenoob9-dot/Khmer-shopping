import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/services/storage_service.dart';

/// Holds the light/dark choice and keeps [AppColors.isLight] in sync.
class ThemeProvider extends ChangeNotifier {
  ThemeProvider(this._storage) : _isLight = _storage.readLightMode() {
    AppColors.isLight = _isLight;
  }

  final StorageService _storage;
  bool _isLight;

  bool get isLight => _isLight;

  void setLight(bool value) {
    if (value == _isLight) return;
    _isLight = value;
    AppColors.isLight = value;
    _storage.writeLightMode(value);
    notifyListeners();
  }

  void toggle() => setLight(!_isLight);
}
