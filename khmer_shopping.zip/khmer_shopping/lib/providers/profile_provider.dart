import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/models/user_profile.dart';
import 'package:khmer_shopping/services/storage_service.dart';

class ProfileProvider extends ChangeNotifier {
  ProfileProvider(this._storage) : _profile = _storage.readProfile();

  final StorageService _storage;
  UserProfile _profile;

  UserProfile get profile => _profile;

  void update(UserProfile profile) {
    _profile = profile;
    _storage.writeProfile(profile);
    notifyListeners();
  }

  void reset() => update(const UserProfile());
}
