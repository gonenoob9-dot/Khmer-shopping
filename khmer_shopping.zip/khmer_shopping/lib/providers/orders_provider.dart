import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/models/cart_item.dart';
import 'package:khmer_shopping/models/order.dart';
import 'package:khmer_shopping/services/storage_service.dart';

class OrdersProvider extends ChangeNotifier {
  OrdersProvider(this._storage) {
    _orders.addAll(_storage.readOrders());
  }

  final StorageService _storage;
  final List<Order> _orders = [];

  /// Newest first.
  List<Order> get orders => List.unmodifiable(_orders);

  int get count => _orders.length;

  Order createOrder({
    required List<CartItem> items,
    required double subtotal,
    required double deliveryFee,
    required double total,
    required String customerName,
    required String phone,
    required String address,
    String note = '',
  }) {
    final now = DateTime.now();
    final suffix = now.millisecondsSinceEpoch.toString();
    final order = Order(
      id: 'KS-${suffix.substring(suffix.length - 6)}',
      createdAt: now,
      items: items
          .map(
            (item) => OrderItem(
              productId: item.product.id,
              name: item.product.name,
              unitPrice: item.product.finalPrice,
              quantity: item.quantity,
            ),
          )
          .toList(),
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      total: total,
      customerName: customerName,
      phone: phone,
      address: address,
      note: note,
    );
    _orders.insert(0, order);
    _storage.writeOrders(_orders);
    notifyListeners();
    return order;
  }

  void clear() {
    if (_orders.isEmpty) return;
    _orders.clear();
    _storage.writeOrders(_orders);
    notifyListeners();
  }
}
