import 'package:flutter/foundation.dart';

import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/services/storage_service.dart';

class FavoritesProvider extends ChangeNotifier {
  FavoritesProvider(this._storage) {
    for (final id in _storage.readFavorites()) {
      if (SampleData.byId(id) != null && !_ids.contains(id)) _ids.add(id);
    }
  }

  final StorageService _storage;
  final List<String> _ids = [];

  List<Product> get products =>
      _ids.map(SampleData.byId).whereType<Product>().toList();

  int get count => _ids.length;

  bool isFavorite(String productId) => _ids.contains(productId);

  void toggle(Product product) {
    if (!_ids.remove(product.id)) {
      _ids.insert(0, product.id);
    }
    _changed();
  }

  void remove(String productId) {
    if (_ids.remove(productId)) _changed();
  }

  void clear() {
    if (_ids.isEmpty) return;
    _ids.clear();
    _changed();
  }

  void _changed() {
    _storage.writeFavorites(_ids);
    notifyListeners();
  }
}
