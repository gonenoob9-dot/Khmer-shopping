import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';

/// Round heart button that toggles a product in the wishlist.
class FavoriteButton extends StatelessWidget {
  const FavoriteButton({super.key, required this.product, this.size = 34});

  final Product product;
  final double size;

  @override
  Widget build(BuildContext context) {
    final isFavorite = context.select<FavoritesProvider, bool>(
      (f) => f.isFavorite(product.id),
    );
    return Material(
      color: Colors.black.withValues(alpha: 0.5),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: () {
          HapticFeedback.lightImpact();
          context.read<FavoritesProvider>().toggle(product);
        },
        child: SizedBox(
          width: size,
          height: size,
          child: AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            transitionBuilder: (child, animation) =>
                ScaleTransition(scale: animation, child: child),
            child: Icon(
              isFavorite ? Icons.favorite : Icons.favorite_border,
              key: ValueKey<bool>(isFavorite),
              size: size * 0.55,
              color: isFavorite ? AppColors.danger : Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}
