import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/models/cart_item.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/widgets/product_card.dart';
import 'package:khmer_shopping/widgets/product_image.dart';
import 'package:khmer_shopping/widgets/quantity_stepper.dart';

/// A swipe-to-delete cart row with quantity controls.
class CartItemTile extends StatelessWidget {
  const CartItemTile({super.key, required this.item});

  final CartItem item;

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final product = item.product;

    void removeItem() {
      final quantity = item.quantity;
      cart.remove(product.id);
      showSnackOn(
        messenger,
        '${product.name} removed',
        actionLabel: 'UNDO',
        onAction: () => cart.add(product, quantity: quantity),
        icon: Icons.delete_outline,
      );
    }

    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: Dismissible(
        key: ValueKey<String>('cart-${product.id}'),
        direction: DismissDirection.endToStart,
        background: Container(
          alignment: Alignment.centerRight,
          padding: EdgeInsets.symmetric(horizontal: 24),
          decoration: BoxDecoration(
            color: AppColors.danger,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Icon(Icons.delete_outline, color: Colors.white),
        ),
        onDismissed: (_) => removeItem(),
        child: Container(
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(18),
            boxShadow: AppColors.cardShadow,
          ),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => openProduct(context, product),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox(
                    width: 84,
                    height: 84,
                    child: ProductImage(product: product),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () => openProduct(context, product),
                            child: Text(
                              product.name,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 14,
                                height: 1.25,
                              ),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: removeItem,
                          borderRadius: BorderRadius.circular(20),
                          child: Padding(
                            padding: EdgeInsets.all(4),
                            child: Icon(
                              Icons.close_rounded,
                              size: 20,
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 2),
                    Text(
                      product.category,
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            formatPrice(item.lineTotal),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppColors.gold,
                              fontWeight: FontWeight.w800,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        QuantityStepper(
                          compact: true,
                          quantity: item.quantity,
                          onIncrement: () => cart.increment(product.id),
                          onDecrement: item.quantity > 1
                              ? () => cart.decrement(product.id)
                              : null,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
