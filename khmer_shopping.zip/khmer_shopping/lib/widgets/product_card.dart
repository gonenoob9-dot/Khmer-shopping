import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/routes.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/screens/product_detail_screen.dart';
import 'package:khmer_shopping/widgets/discount_badge.dart';
import 'package:khmer_shopping/widgets/favorite_button.dart';
import 'package:khmer_shopping/widgets/price_row.dart';
import 'package:khmer_shopping/widgets/product_image.dart';

/// Opens the product details page.
void openProduct(BuildContext context, Product product) {
  Navigator.of(context).push(
    slideFadeRoute<void>(ProductDetailScreen(product: product)),
  );
}

/// Adds one unit of [product] to the cart and shows feedback.
void quickAddToCart(BuildContext context, Product product) {
  HapticFeedback.mediumImpact();
  context.read<CartProvider>().add(product);
  showAppSnack(
    context,
    '${product.name} added to cart',
    actionLabel: 'VIEW CART',
    onAction: () => AppNavigator.goToTab(AppTabs.cart),
    icon: Icons.shopping_bag,
  );
}

/// Professional product card used in grids and horizontal lists. It expands to
/// the size given by its parent (fixed height required).
class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product});

  final Product product;

  @override
  Widget build(BuildContext context) {
    final scaler = MediaQuery.textScalerOf(context);
    final nameHeight = scaler.scale(13 * 1.25 * 2);

    return Material(
      color: AppColors.card,
      elevation: AppColors.isLight ? 2 : 0,
      shadowColor: Colors.black38,
      borderRadius: BorderRadius.circular(18),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => openProduct(context, product),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ProductImage(product: product),
                  if (product.hasDiscount)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: DiscountBadge(percent: product.discountPercent),
                    ),
                  Positioned(
                    top: 6,
                    right: 6,
                    child: FavoriteButton(product: product, size: 32),
                  ),
                  Positioned(
                    right: 8,
                    bottom: 8,
                    child: Material(
                      color: AppColors.goldFill,
                      shape: CircleBorder(),
                      child: InkWell(
                        customBorder: CircleBorder(),
                        onTap: () => quickAddToCart(context, product),
                        child: SizedBox(
                          width: 34,
                          height: 34,
                          child: Icon(
                            Icons.add_shopping_cart,
                            size: 18,
                            color: AppColors.onGold,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: nameHeight,
                    child: Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        height: 1.25,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.star_rounded,
                          size: 14, color: AppColors.gold),
                      SizedBox(width: 3),
                      Flexible(
                        child: Text(
                          '${product.rating.toStringAsFixed(1)} (${formatCount(product.reviewCount)})',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 11,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  PriceRow(product: product),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
