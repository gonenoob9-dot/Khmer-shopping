import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/theme.dart';

class DiscountBadge extends StatelessWidget {
  const DiscountBadge({super.key, required this.percent, this.large = false});

  final int percent;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: large ? 12 : 8,
        vertical: large ? 6 : 4,
      ),
      decoration: BoxDecoration(
        gradient: AppColors.goldGradient,
        borderRadius: BorderRadius.circular(large ? 12 : 8),
      ),
      child: Text(
        '-$percent%',
        style: TextStyle(
          color: AppColors.black,
          fontWeight: FontWeight.w800,
          fontSize: large ? 14 : 11,
        ),
      ),
    );
  }
}
