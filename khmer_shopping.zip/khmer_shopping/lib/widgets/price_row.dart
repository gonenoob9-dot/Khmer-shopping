import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/models/product.dart';

/// Final price in gold, with the original price struck through if discounted.
class PriceRow extends StatelessWidget {
  const PriceRow({super.key, required this.product, this.large = false});

  final Product product;
  final bool large;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Flexible(
          child: Text(
            formatPrice(product.finalPrice),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: AppColors.gold,
              fontWeight: FontWeight.w800,
              fontSize: large ? 28 : 15,
            ),
          ),
        ),
        if (product.hasDiscount) ...[
          SizedBox(width: large ? 10 : 6),
          Flexible(
            child: Text(
              formatPrice(product.price),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: AppColors.textSecondary,
                decoration: TextDecoration.lineThrough,
                decorationColor: AppColors.textSecondary,
                fontSize: large ? 16 : 11,
              ),
            ),
          ),
        ],
      ],
    );
  }
}
