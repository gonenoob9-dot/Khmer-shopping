import 'dart:async';

import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/theme.dart';

class PromoItem {
  const PromoItem({
    required this.title,
    required this.subtitle,
    required this.cta,
    required this.icon,
    required this.colors,
    this.category,
  });

  final String title;
  final String subtitle;
  final String cta;
  final IconData icon;
  final List<Color> colors;

  /// Category opened when the banner is tapped (null shows everything).
  final String? category;
}

const List<PromoItem> kPromoItems = [
  PromoItem(
    title: 'Up to 30% OFF',
    subtitle: 'Premium electronics and gadgets',
    cta: 'Shop Electronics',
    icon: Icons.headphones,
    colors: [Color(0xFF3A2F0B), Color(0xFF14110A)],
    category: 'Electronics',
  ),
  PromoItem(
    title: 'New Season Style',
    subtitle: 'Fresh fashion picks, just landed',
    cta: 'Shop Fashion',
    icon: Icons.checkroom,
    colors: [Color(0xFF3A2216), Color(0xFF120C09)],
    category: 'Fashion',
  ),
  PromoItem(
    title: 'Free Delivery',
    subtitle: 'On all orders over \$100',
    cta: 'Start Shopping',
    icon: Icons.local_shipping,
    colors: [Color(0xFF2B2B2B), Color(0xFF0E0E0E)],
  ),
];

/// Auto-sliding promotional banner carousel with page dots.
class PromoBanner extends StatefulWidget {
  const PromoBanner({super.key, required this.onTap});

  final ValueChanged<PromoItem> onTap;

  @override
  State<PromoBanner> createState() => _PromoBannerState();
}

class _PromoBannerState extends State<PromoBanner> {
  final PageController _controller = PageController(viewportFraction: 0.92);
  Timer? _timer;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(Duration(seconds: 4), (_) {
      if (!mounted || !_controller.hasClients) return;
      final next = (_page + 1) % kPromoItems.length;
      _controller.animateToPage(
        next,
        duration: Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 168,
          child: PageView.builder(
            controller: _controller,
            itemCount: kPromoItems.length,
            onPageChanged: (index) => setState(() => _page = index),
            itemBuilder: (context, index) {
              final item = kPromoItems[index];
              return Padding(
                padding: EdgeInsets.symmetric(horizontal: 5),
                child: _BannerCard(
                  item: item,
                  onTap: () => widget.onTap(item),
                ),
              );
            },
          ),
        ),
        SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (var i = 0; i < kPromoItems.length; i++)
              AnimatedContainer(
                duration: Duration(milliseconds: 300),
                margin: EdgeInsets.symmetric(horizontal: 3),
                width: i == _page ? 22 : 7,
                height: 7,
                decoration: BoxDecoration(
                  color: i == _page ? AppColors.goldFill : AppColors.cardLight,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
          ],
        ),
      ],
    );
  }
}

class _BannerCard extends StatelessWidget {
  const _BannerCard({required this.item, required this.onTap});

  final PromoItem item;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: item.colors,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.gold.withValues(alpha: 0.3)),
        ),
        child: InkWell(
          onTap: onTap,
          child: Stack(
            children: [
              Positioned(
                right: -20,
                bottom: -24,
                child: Icon(
                  item.icon,
                  size: 150,
                  color: AppColors.gold.withValues(alpha: 0.16),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ShaderMask(
                      blendMode: BlendMode.srcIn,
                      shaderCallback: (bounds) =>
                          AppColors.goldGradient.createShader(bounds),
                      child: Text(
                        item.title,
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(height: 6),
                    Text(
                      item.subtitle,
                      style: TextStyle(
                        color: Color(0xFFBDBDBD),
                        fontSize: 13,
                      ),
                    ),
                    SizedBox(height: 14),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        gradient: AppColors.goldGradient,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        item.cta,
                        style: TextStyle(
                          color: AppColors.onGold,
                          fontWeight: FontWeight.w800,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
