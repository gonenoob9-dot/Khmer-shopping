import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/product.dart';

/// Premium "artwork" for a product: a dark category-tinted gradient with a
/// gold-gradient icon. Version 1 uses local sample data, so no network images
/// are needed. Replace with Image.network / Image.asset when real photos exist.
class ProductImage extends StatelessWidget {
  const ProductImage({super.key, required this.product, this.iconScale = 0.4});

  final Product product;
  final double iconScale;

  @override
  Widget build(BuildContext context) {
    final tint = SampleData.categoryOf(product.category).tint;
    return LayoutBuilder(
      builder: (context, constraints) {
        final width =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 120.0;
        final height =
            constraints.maxHeight.isFinite ? constraints.maxHeight : 120.0;
        final side = math.min(width, height);
        return DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [tint, const Color(0xFF0E0E0E)],
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Positioned(
                right: -side * 0.18,
                top: -side * 0.18,
                child: Container(
                  width: side * 0.75,
                  height: side * 0.75,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.gold.withValues(alpha: 0.07),
                  ),
                ),
              ),
              Positioned(
                left: -side * 0.22,
                bottom: -side * 0.22,
                child: Container(
                  width: side * 0.7,
                  height: side * 0.7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.gold.withValues(alpha: 0.04),
                  ),
                ),
              ),
              Center(
                child: Container(
                  width: side * 0.62,
                  height: side * 0.62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppColors.gold.withValues(alpha: 0.22),
                    ),
                    color: Colors.black.withValues(alpha: 0.25),
                  ),
                  child: Center(
                    child: ShaderMask(
                      blendMode: BlendMode.srcIn,
                      shaderCallback: (bounds) =>
                          AppColors.goldGradient.createShader(bounds),
                      child: Icon(
                        product.icon,
                        size: side * iconScale,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
