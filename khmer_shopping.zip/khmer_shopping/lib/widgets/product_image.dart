import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/product.dart';

/// Product picture. A gradient + gold icon "artwork" is always drawn first;
/// if the product has an image URL (see data/image_overrides.dart) the photo
/// fades in on top of it. If the phone is offline or the link is broken, the
/// artwork simply stays visible, so the app never shows a broken image.
class ProductImage extends StatelessWidget {
  const ProductImage({super.key, required this.product, this.iconScale = 0.4});

  final Product product;
  final double iconScale;

  @override
  Widget build(BuildContext context) {
    final tint = AppColors.artTint(SampleData.categoryOf(product.category).tint);
    final url = SampleData.imageUrlFor(product);
    return LayoutBuilder(
      builder: (context, constraints) {
        final width =
            constraints.maxWidth.isFinite ? constraints.maxWidth : 120.0;
        final height =
            constraints.maxHeight.isFinite ? constraints.maxHeight : 120.0;
        final side = math.min(width, height);
        return DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [tint, AppColors.artEnd],
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Positioned(
                right: -side * 0.18,
                top: -side * 0.18,
                child: Container(
                  width: side * 0.75,
                  height: side * 0.75,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.goldFill.withValues(alpha: 0.10),
                  ),
                ),
              ),
              Positioned(
                left: -side * 0.22,
                bottom: -side * 0.22,
                child: Container(
                  width: side * 0.7,
                  height: side * 0.7,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.goldFill.withValues(alpha: 0.07),
                  ),
                ),
              ),
              Center(
                child: Container(
                  width: side * 0.62,
                  height: side * 0.62,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: AppColors.goldFill.withValues(alpha: 0.35),
                    ),
                    color: AppColors.isLight
                        ? Colors.white.withValues(alpha: 0.55)
                        : Colors.black.withValues(alpha: 0.25),
                  ),
                  child: Center(
                    child: ShaderMask(
                      blendMode: BlendMode.srcIn,
                      shaderCallback: (bounds) =>
                          AppColors.goldGradient.createShader(bounds),
                      child: Icon(
                        product.icon,
                        size: side * iconScale,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
              if (url != null)
                Image.network(
                  url,
                  fit: BoxFit.cover,
                  cacheWidth: 600,
                  gaplessPlayback: true,
                  frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
                    return AnimatedOpacity(
                      opacity: frame == null ? 0 : 1,
                      duration: Duration(milliseconds: 450),
                      child: child,
                    );
                  },
                  errorBuilder: (context, error, stackTrace) =>
                      SizedBox.shrink(),
                ),
            ],
          ),
        );
      },
    );
  }
}
