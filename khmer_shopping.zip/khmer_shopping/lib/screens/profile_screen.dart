import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/routes.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/providers/orders_provider.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/screens/edit_profile_screen.dart';
import 'package:khmer_shopping/screens/order_history_screen.dart';
import 'package:khmer_shopping/screens/settings_screen.dart';
import 'package:khmer_shopping/widgets/app_logo.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).push(slideFadeRoute<void>(page));
  }

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<ProfileProvider>().profile;
    final orderCount = context.select<OrdersProvider, int>((o) => o.count);
    final favCount = context.select<FavoritesProvider, int>((f) => f.count);
    final cartCount = context.select<CartProvider, int>((c) => c.itemCount);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          // ---- Customer card ----
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF2E260C), AppColors.card],
              ),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppColors.gold.withValues(alpha: 0.3)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      width: 68,
                      height: 68,
                      alignment: Alignment.center,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.goldGradient,
                      ),
                      child: Text(
                        profile.initials,
                        style: const TextStyle(
                          color: AppColors.black,
                          fontSize: 26,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            profile.displayName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            profile.phone.isEmpty
                                ? 'No phone number yet'
                                : profile.phone,
                            style: const TextStyle(
                              color: AppColors.textSecondary,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            profile.address.isEmpty
                                ? 'No delivery address yet'
                                : profile.address,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 12.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => _push(context, const EditProfileScreen()),
                    icon: const Icon(Icons.edit_outlined, size: 18),
                    label: Text(
                      profile.isEmpty ? 'Add my information' : 'Edit information',
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // ---- Stats ----
          Row(
            children: [
              Expanded(
                child: _StatCard(
                  icon: Icons.receipt_long_outlined,
                  value: '$orderCount',
                  label: 'Orders',
                  onTap: () => _push(context, const OrderHistoryScreen()),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  icon: Icons.favorite_border,
                  value: '$favCount',
                  label: 'Wishlist',
                  onTap: () => AppNavigator.goToTab(AppTabs.wishlist),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _StatCard(
                  icon: Icons.shopping_bag_outlined,
                  value: '$cartCount',
                  label: 'In cart',
                  onTap: () => AppNavigator.goToTab(AppTabs.cart),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // ---- Menu ----
          _MenuTile(
            icon: Icons.receipt_long_outlined,
            title: 'Order History',
            subtitle: orderCount == 0
                ? 'No orders yet'
                : '$orderCount order${orderCount == 1 ? '' : 's'} placed',
            onTap: () => _push(context, const OrderHistoryScreen()),
          ),
          _MenuTile(
            icon: Icons.person_outline,
            title: 'Customer Information',
            subtitle: 'Name, phone number and address',
            onTap: () => _push(context, const EditProfileScreen()),
          ),
          _MenuTile(
            icon: Icons.favorite_border,
            title: 'My Wishlist',
            subtitle: '$favCount saved product${favCount == 1 ? '' : 's'}',
            onTap: () => AppNavigator.goToTab(AppTabs.wishlist),
          ),
          _MenuTile(
            icon: Icons.settings_outlined,
            title: 'Settings',
            subtitle: 'Notifications, data and about',
            onTap: () => _push(context, const SettingsScreen()),
          ),
          _MenuTile(
            icon: Icons.info_outline,
            title: 'About ${AppConfig.appName}',
            subtitle: 'Version ${AppConfig.version}',
            onTap: () => showAboutApp(context),
          ),
        ],
      ),
    );
  }
}

void showAboutApp(BuildContext context) {
  showAboutDialog(
    context: context,
    applicationName: AppConfig.appName,
    applicationVersion: AppConfig.version,
    applicationIcon: const AppLogo(size: 48),
    children: const [
      SizedBox(height: 12),
      Text(
        'A premium online shopping experience. Version 1 uses local sample '
        'products and stores your cart, favorites and orders on this device.',
      ),
    ],
  );
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String value;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.card,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(
            children: [
              Icon(icon, color: AppColors.gold),
              const SizedBox(height: 6),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                  color: AppColors.textSecondary,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: AppColors.gold.withValues(alpha: 0.14),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: AppColors.gold),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 12.5,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.chevron_right,
                  color: AppColors.textSecondary,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
