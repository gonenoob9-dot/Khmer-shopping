import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/widgets/cart_icon_button.dart';
import 'package:khmer_shopping/widgets/discount_badge.dart';
import 'package:khmer_shopping/widgets/favorite_button.dart';
import 'package:khmer_shopping/widgets/gold_button.dart';
import 'package:khmer_shopping/widgets/price_row.dart';
import 'package:khmer_shopping/widgets/product_card.dart';
import 'package:khmer_shopping/widgets/product_image.dart';
import 'package:khmer_shopping/widgets/quantity_stepper.dart';

class ProductDetailScreen extends StatefulWidget {
  const ProductDetailScreen({super.key, required this.product});

  final Product product;

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _quantity = 1;
  bool _justAdded = false;

  Product get product => widget.product;

  Future<void> _addToCart() async {
    HapticFeedback.mediumImpact();
    context.read<CartProvider>().add(product, quantity: _quantity);
    showAppSnack(
      context,
      '$_quantity x ${product.name} added to cart',
      actionLabel: 'VIEW CART',
      onAction: () => AppNavigator.goToTab(AppTabs.cart),
      icon: Icons.shopping_bag,
    );
    setState(() => _justAdded = true);
    await Future<void>.delayed(const Duration(milliseconds: 1400));
    if (mounted) setState(() => _justAdded = false);
  }

  @override
  Widget build(BuildContext context) {
    final related = SampleData.related(product);
    final width = MediaQuery.sizeOf(context).width;
    final relatedWidth = (width * 0.42).clamp(145.0, 190.0).toDouble();
    final total = roundMoney(product.finalPrice * _quantity);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 340,
            backgroundColor: AppColors.black,
            automaticallyImplyLeading: false,
            leading: Padding(
              padding: const EdgeInsets.all(8),
              child: Material(
                color: Colors.black.withValues(alpha: 0.5),
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => Navigator.of(context).maybePop(),
                  child: const Icon(Icons.arrow_back_ios_new, size: 18),
                ),
              ),
            ),
            actions: [
              const CartIconButton(),
              Padding(
                padding: const EdgeInsets.only(right: 12, left: 4),
                child: Center(
                  child: FavoriteButton(product: product, size: 40),
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              collapseMode: CollapseMode.parallax,
              background: Stack(
                fit: StackFit.expand,
                children: [
                  ProductImage(product: product, iconScale: 0.36),
                  if (product.hasDiscount)
                    Positioned(
                      left: 20,
                      bottom: 40,
                      child: DiscountBadge(
                        percent: product.discountPercent,
                        large: true,
                      ),
                    ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Container(
              transform: Matrix4.translationValues(0, -24, 0),
              decoration: const BoxDecoration(
                color: AppColors.black,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
              ),
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.gold.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      product.category.toUpperCase(),
                      style: const TextStyle(
                        color: AppColors.gold,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      height: 1.2,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.star_rounded,
                          color: AppColors.gold, size: 20),
                      const SizedBox(width: 4),
                      Text(
                        product.rating.toStringAsFixed(1),
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '(${formatCount(product.reviewCount)} reviews)',
                        style: const TextStyle(color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  PriceRow(product: product, large: true),
                  if (product.hasDiscount) ...[
                    const SizedBox(height: 6),
                    Text(
                      'You save ${formatPrice(product.savings)} (${product.discountPercent}% off)',
                      style: const TextStyle(
                        color: AppColors.success,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                  const Divider(),
                  const SizedBox(height: 20),
                  const Text(
                    'Description',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    product.description,
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      height: 1.55,
                      fontSize: 14.5,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      const Expanded(
                        child: Text(
                          'Quantity',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                      QuantityStepper(
                        quantity: _quantity,
                        onDecrement: _quantity > 1
                            ? () => setState(() => _quantity--)
                            : null,
                        onIncrement: _quantity < 99
                            ? () => setState(() => _quantity++)
                            : null,
                      ),
                    ],
                  ),
                  if (related.isNotEmpty) ...[
                    const SizedBox(height: 28),
                    const Text(
                      'You may also like',
                      style:
                          TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 12),
                  ],
                ],
              ),
            ),
          ),
          if (related.isNotEmpty)
            SliverToBoxAdapter(
              child: Transform.translate(
                offset: const Offset(0, -24),
                child: SizedBox(
                  height: productCardHeight(context, relatedWidth),
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: related.length,
                    separatorBuilder: (context, index) =>
                        const SizedBox(width: 12),
                    itemBuilder: (context, index) => SizedBox(
                      width: relatedWidth,
                      child: ProductCard(product: related[index]),
                    ),
                  ),
                ),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 8)),
        ],
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(
            top: BorderSide(color: Colors.white.withValues(alpha: 0.06)),
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
            child: Row(
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Total',
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      formatPrice(total),
                      style: const TextStyle(
                        color: AppColors.gold,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: GoldButton(
                    label: _justAdded ? 'Added to Cart' : 'Add to Cart',
                    icon: _justAdded
                        ? Icons.check_circle
                        : Icons.add_shopping_cart,
                    onPressed: _addToCart,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
