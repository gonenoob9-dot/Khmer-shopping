import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/routes.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/screens/checkout_screen.dart';
import 'package:khmer_shopping/widgets/cart_item_tile.dart';
import 'package:khmer_shopping/widgets/empty_state.dart';
import 'package:khmer_shopping/widgets/gold_button.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final items = cart.items;

    return Scaffold(
      appBar: AppBar(
        title: Text(items.isEmpty ? 'My Cart' : 'My Cart (${cart.itemCount})'),
        actions: [
          if (items.isNotEmpty)
            IconButton(
              tooltip: 'Empty cart',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () async {
                final provider = context.read<CartProvider>();
                final ok = await confirmDialog(
                  context,
                  title: 'Empty your cart?',
                  message: 'All items will be removed from your cart.',
                  confirmLabel: 'Empty',
                );
                if (ok) provider.clear();
              },
            ),
        ],
      ),
      body: items.isEmpty
          ? EmptyState(
              icon: Icons.shopping_bag_outlined,
              title: 'Your cart is empty',
              message: 'Looks like you have not added anything yet.',
              buttonLabel: 'Start shopping',
              onPressed: () => AppNavigator.goToTab(AppTabs.home),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: items.length,
                    itemBuilder: (context, index) =>
                        CartItemTile(key: ValueKey(items[index].product.id), item: items[index]),
                  ),
                ),
                _CartSummary(cart: cart),
              ],
            ),
    );
  }
}

class _CartSummary extends StatelessWidget {
  const _CartSummary({required this.cart});

  final CartProvider cart;

  @override
  Widget build(BuildContext context) {
    final subtotal = cart.subtotal;
    final remaining = AppConfig.freeDeliveryThreshold - subtotal;
    final progress =
        (subtotal / AppConfig.freeDeliveryThreshold).clamp(0.0, 1.0).toDouble();

    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border(
          top: BorderSide(color: AppColors.gold.withValues(alpha: 0.25)),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(
                remaining <= 0 ? Icons.check_circle : Icons.local_shipping,
                size: 18,
                color: remaining <= 0 ? AppColors.success : AppColors.gold,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  remaining <= 0
                      ? 'You unlocked free delivery!'
                      : 'Add ${formatPrice(remaining)} more for free delivery',
                  style: const TextStyle(fontSize: 13),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(value: progress, minHeight: 6),
          ),
          const SizedBox(height: 16),
          _SummaryRow(label: 'Subtotal', value: formatPrice(subtotal)),
          const SizedBox(height: 6),
          _SummaryRow(
            label: 'Delivery',
            value: cart.deliveryFee == 0 ? 'FREE' : formatPrice(cart.deliveryFee),
            valueColor: cart.deliveryFee == 0 ? AppColors.success : null,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Divider(),
          ),
          _SummaryRow(
            label: 'Total',
            value: formatPrice(cart.total),
            large: true,
          ),
          const SizedBox(height: 14),
          GoldButton(
            label: 'Proceed to Checkout',
            icon: Icons.lock_outline,
            onPressed: () => Navigator.of(context).push(
              slideFadeRoute<void>(const CheckoutScreen()),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.label,
    required this.value,
    this.large = false,
    this.valueColor,
  });

  final String label;
  final String value;
  final bool large;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontSize: large ? 18 : 14,
              fontWeight: large ? FontWeight.w800 : FontWeight.w500,
              color: large ? AppColors.textPrimary : AppColors.textSecondary,
            ),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: large ? 22 : 14,
            fontWeight: FontWeight.w800,
            color: valueColor ?? (large ? AppColors.gold : AppColors.textPrimary),
          ),
        ),
      ],
    );
  }
}
