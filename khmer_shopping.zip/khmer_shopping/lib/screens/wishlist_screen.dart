import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/widgets/empty_state.dart';
import 'package:khmer_shopping/widgets/fade_slide_in.dart';
import 'package:khmer_shopping/widgets/product_card.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final products = favorites.products;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          products.isEmpty ? 'My Wishlist' : 'My Wishlist (${products.length})',
        ),
        actions: [
          if (products.isNotEmpty)
            IconButton(
              tooltip: 'Remove all',
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () async {
                final provider = context.read<FavoritesProvider>();
                final ok = await confirmDialog(
                  context,
                  title: 'Clear wishlist?',
                  message: 'All saved favorites will be removed.',
                  confirmLabel: 'Clear',
                );
                if (ok) provider.clear();
              },
            ),
        ],
      ),
      body: products.isEmpty
          ? EmptyState(
              icon: Icons.favorite_border,
              title: 'Your wishlist is empty',
              message:
                  'Tap the heart on any product to save it here for later.',
              buttonLabel: 'Explore products',
              onPressed: () => AppNavigator.goToTab(AppTabs.home),
            )
          : GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              gridDelegate: productGridDelegate(context),
              itemCount: products.length,
              itemBuilder: (context, index) => FadeSlideIn(
                key: ValueKey<String>('wish-${products[index].id}'),
                index: index,
                child: ProductCard(product: products[index]),
              ),
            ),
    );
  }
}
