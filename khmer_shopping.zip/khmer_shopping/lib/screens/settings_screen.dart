import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/providers/orders_provider.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/providers/search_provider.dart';
import 'package:khmer_shopping/providers/settings_provider.dart';
import 'package:khmer_shopping/screens/profile_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final orders = context.watch<OrdersProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _GroupLabel('General'),
          _Group(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.notifications_none,
                    color: AppColors.gold),
                title: const Text('Order notifications'),
                subtitle: const Text('Get updates about your orders'),
                value: settings.notifications,
                onChanged: (value) {
                  context.read<SettingsProvider>().setNotifications(value);
                  showAppSnack(
                    context,
                    value ? 'Notifications on' : 'Notifications off',
                    icon: value
                        ? Icons.notifications_active
                        : Icons.notifications_off,
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.history, color: AppColors.gold),
                title: const Text('Clear recent searches'),
                subtitle: Text(
                  '${settings.recentSearches.length} saved search'
                  '${settings.recentSearches.length == 1 ? '' : 'es'}',
                ),
                onTap: () {
                  context.read<SettingsProvider>().clearRecentSearches();
                  showAppSnack(context, 'Recent searches cleared');
                },
              ),
              ListTile(
                leading: const Icon(Icons.payments_outlined,
                    color: AppColors.gold),
                title: const Text('Payment method'),
                subtitle: const Text('Cash on Delivery (demo)'),
                trailing: const Icon(Icons.check_circle, color: AppColors.gold),
                onTap: () => showAppSnack(
                  context,
                  'Cash on Delivery is the only method in Version 1',
                  icon: Icons.info_outline,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const _GroupLabel('Data'),
          _Group(
            children: [
              ListTile(
                leading: const Icon(Icons.receipt_long_outlined,
                    color: AppColors.gold),
                title: const Text('Clear order history'),
                subtitle: Text('${orders.count} saved order(s)'),
                onTap: () async {
                  final provider = context.read<OrdersProvider>();
                  final messenger = ScaffoldMessenger.of(context);
                  final ok = await confirmDialog(
                    context,
                    title: 'Clear order history?',
                    message: 'All past orders on this device will be deleted.',
                    confirmLabel: 'Clear',
                  );
                  if (!ok) return;
                  provider.clear();
                  showSnackOn(messenger, 'Order history cleared');
                },
              ),
              ListTile(
                leading: const Icon(Icons.restart_alt, color: AppColors.danger),
                title: const Text(
                  'Reset all app data',
                  style: TextStyle(color: AppColors.danger),
                ),
                subtitle: const Text(
                  'Cart, wishlist, orders, profile and settings',
                ),
                onTap: () async {
                  final cart = context.read<CartProvider>();
                  final favorites = context.read<FavoritesProvider>();
                  final ordersProvider = context.read<OrdersProvider>();
                  final profile = context.read<ProfileProvider>();
                  final settingsProvider = context.read<SettingsProvider>();
                  final search = context.read<SearchProvider>();
                  final messenger = ScaffoldMessenger.of(context);
                  final ok = await confirmDialog(
                    context,
                    title: 'Reset everything?',
                    message:
                        'This permanently removes your cart, wishlist, orders, profile and settings from this device.',
                    confirmLabel: 'Reset',
                  );
                  if (!ok) return;
                  cart.clear();
                  favorites.clear();
                  ordersProvider.clear();
                  profile.reset();
                  settingsProvider.reset();
                  search.clearAll();
                  showSnackOn(messenger, 'All app data has been reset');
                },
              ),
            ],
          ),
          const SizedBox(height: 20),
          const _GroupLabel('About'),
          _Group(
            children: [
              ListTile(
                leading: const Icon(Icons.info_outline, color: AppColors.gold),
                title: const Text('About ${AppConfig.appName}'),
                subtitle: const Text('Version ${AppConfig.version}'),
                onTap: () => showAboutApp(context),
              ),
              ListTile(
                leading: const Icon(Icons.description_outlined,
                    color: AppColors.gold),
                title: const Text('Open-source licenses'),
                onTap: () => showLicensePage(
                  context: context,
                  applicationName: AppConfig.appName,
                  applicationVersion: AppConfig.version,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GroupLabel extends StatelessWidget {
  const _GroupLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: AppColors.gold,
          fontWeight: FontWeight.w800,
          fontSize: 12,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Material(
        color: AppColors.card,
        child: Column(
          children: [
            for (var i = 0; i < children.length; i++) ...[
              children[i],
              if (i != children.length - 1) const Divider(indent: 16, endIndent: 16),
            ],
          ],
        ),
      ),
    );
  }
}
