import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/providers/orders_provider.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/providers/search_provider.dart';
import 'package:khmer_shopping/providers/settings_provider.dart';
import 'package:khmer_shopping/providers/theme_provider.dart';
import 'package:khmer_shopping/screens/profile_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();
    final orders = context.watch<OrdersProvider>();
    final themeProvider = context.watch<ThemeProvider>();

    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          _GroupLabel('Appearance'),
          _Group(
            children: [
              SwitchListTile(
                secondary: Icon(
                  themeProvider.isLight
                      ? Icons.light_mode_outlined
                      : Icons.dark_mode_outlined,
                  color: AppColors.gold,
                ),
                title: Text('Light mode'),
                subtitle: Text(
                  themeProvider.isLight
                      ? 'Bright theme is on'
                      : 'Dark gold theme is on',
                ),
                value: themeProvider.isLight,
                onChanged: (value) =>
                    context.read<ThemeProvider>().setLight(value),
              ),
            ],
          ),
          SizedBox(height: 20),
          _GroupLabel('General'),
          _Group(
            children: [
              SwitchListTile(
                secondary: Icon(Icons.notifications_none,
                    color: AppColors.gold),
                title: Text('Order notifications'),
                subtitle: Text('Get updates about your orders'),
                value: settings.notifications,
                onChanged: (value) {
                  context.read<SettingsProvider>().setNotifications(value);
                  showAppSnack(
                    context,
                    value ? 'Notifications on' : 'Notifications off',
                    icon: value
                        ? Icons.notifications_active
                        : Icons.notifications_off,
                  );
                },
              ),
              ListTile(
                leading: Icon(Icons.history, color: AppColors.gold),
                title: Text('Clear recent searches'),
                subtitle: Text(
                  '${settings.recentSearches.length} saved search'
                  '${settings.recentSearches.length == 1 ? '' : 'es'}',
                ),
                onTap: () {
                  context.read<SettingsProvider>().clearRecentSearches();
                  showAppSnack(context, 'Recent searches cleared');
                },
              ),
              ListTile(
                leading: Icon(Icons.payments_outlined,
                    color: AppColors.gold),
                title: Text('Payment method'),
                subtitle: Text('Cash on Delivery (demo)'),
                trailing: Icon(Icons.check_circle, color: AppColors.gold),
                onTap: () => showAppSnack(
                  context,
                  'Cash on Delivery is the only method in Version 1',
                  icon: Icons.info_outline,
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          _GroupLabel('Data'),
          _Group(
            children: [
              ListTile(
                leading: Icon(Icons.receipt_long_outlined,
                    color: AppColors.gold),
                title: Text('Clear order history'),
                subtitle: Text('${orders.count} saved order(s)'),
                onTap: () async {
                  final provider = context.read<OrdersProvider>();
                  final messenger = ScaffoldMessenger.of(context);
                  final ok = await confirmDialog(
                    context,
                    title: 'Clear order history?',
                    message: 'All past orders on this device will be deleted.',
                    confirmLabel: 'Clear',
                  );
                  if (!ok) return;
                  provider.clear();
                  showSnackOn(messenger, 'Order history cleared');
                },
              ),
              ListTile(
                leading: Icon(Icons.restart_alt, color: AppColors.danger),
                title: Text(
                  'Reset all app data',
                  style: TextStyle(color: AppColors.danger),
                ),
                subtitle: Text(
                  'Cart, wishlist, orders, profile and settings',
                ),
                onTap: () async {
                  final cart = context.read<CartProvider>();
                  final favorites = context.read<FavoritesProvider>();
                  final ordersProvider = context.read<OrdersProvider>();
                  final profile = context.read<ProfileProvider>();
                  final settingsProvider = context.read<SettingsProvider>();
                  final search = context.read<SearchProvider>();
                  final themeCtl = context.read<ThemeProvider>();
                  final messenger = ScaffoldMessenger.of(context);
                  final ok = await confirmDialog(
                    context,
                    title: 'Reset everything?',
                    message:
                        'This permanently removes your cart, wishlist, orders, profile and settings from this device.',
                    confirmLabel: 'Reset',
                  );
                  if (!ok) return;
                  cart.clear();
                  favorites.clear();
                  ordersProvider.clear();
                  profile.reset();
                  settingsProvider.reset();
                  themeCtl.setLight(false);
                  search.clearAll();
                  showSnackOn(messenger, 'All app data has been reset');
                },
              ),
            ],
          ),
          SizedBox(height: 20),
          _GroupLabel('About'),
          _Group(
            children: [
              ListTile(
                leading: Icon(Icons.info_outline, color: AppColors.gold),
                title: Text('About ${AppConfig.appName}'),
                subtitle: Text('Version ${AppConfig.version}'),
                onTap: () => showAboutApp(context),
              ),
              ListTile(
                leading: Icon(Icons.description_outlined,
                    color: AppColors.gold),
                title: Text('Open-source licenses'),
                onTap: () => showLicensePage(
                  context: context,
                  applicationName: AppConfig.appName,
                  applicationVersion: AppConfig.version,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GroupLabel extends StatelessWidget {
  const _GroupLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          color: AppColors.gold,
          fontWeight: FontWeight.w800,
          fontSize: 12,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _Group extends StatelessWidget {
  const _Group({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Material(
        color: AppColors.card,
        child: Column(
          children: [
            for (var i = 0; i < children.length; i++) ...[
              children[i],
              if (i != children.length - 1) Divider(indent: 16, endIndent: 16),
            ],
          ],
        ),
      ),
    );
  }
}
