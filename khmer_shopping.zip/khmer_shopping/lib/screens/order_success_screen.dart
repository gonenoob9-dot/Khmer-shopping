import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/routes.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/models/order.dart';
import 'package:khmer_shopping/screens/order_history_screen.dart';
import 'package:khmer_shopping/widgets/gold_button.dart';

class OrderSuccessScreen extends StatelessWidget {
  const OrderSuccessScreen({super.key, required this.order});

  final Order order;

  void _viewOrders() {
    AppNavigator.goToTab(AppTabs.profile);
    AppNavigator.push<void>(slideFadeRoute<void>(OrderHistoryScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) AppNavigator.goToTab(AppTabs.home);
      },
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: 480),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TweenAnimationBuilder<double>(
                      tween: Tween<double>(begin: 0, end: 1),
                      duration: Duration(milliseconds: 900),
                      curve: Curves.elasticOut,
                      builder: (context, value, child) =>
                          Transform.scale(scale: value, child: child),
                      child: Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: AppColors.goldGradient,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.gold.withValues(alpha: 0.4),
                              blurRadius: 30,
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.check_rounded,
                          size: 70,
                          color: AppColors.onGold,
                        ),
                      ),
                    ),
                    SizedBox(height: 28),
                    Text(
                      'Order Confirmed!',
                      style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Thank you for shopping with Khmer Shopping.\nPay with cash when your order arrives.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppColors.textSecondary,
                        height: 1.45,
                      ),
                    ),
                    SizedBox(height: 24),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: AppColors.gold.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Column(
                        children: [
                          _InfoRow(label: 'Order number', value: order.id),
                          _InfoRow(
                            label: 'Items',
                            value: '${order.itemCount}',
                          ),
                          _InfoRow(
                            label: 'Payment',
                            value: order.paymentMethod,
                          ),
                          _InfoRow(
                            label: 'Deliver to',
                            value: order.customerName,
                          ),
                          _InfoRow(label: 'Phone', value: order.phone),
                          _InfoRow(label: 'Address', value: order.address),
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 8),
                            child: Divider(),
                          ),
                          _InfoRow(
                            label: 'Total to pay',
                            value: formatPrice(order.total),
                            highlight: true,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 28),
                    GoldButton(
                      label: 'Continue Shopping',
                      icon: Icons.storefront_outlined,
                      onPressed: () => AppNavigator.goToTab(AppTabs.home),
                    ),
                    SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _viewOrders,
                        icon: Icon(Icons.receipt_long_outlined),
                        label: Text('View My Orders'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({
    required this.label,
    required this.value,
    this.highlight = false,
  });

  final String label;
  final String value;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 104,
            child: Text(
              label,
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                fontSize: highlight ? 18 : 14,
                color: highlight ? AppColors.gold : AppColors.textPrimary,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
