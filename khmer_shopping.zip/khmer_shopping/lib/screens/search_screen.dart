import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/providers/search_provider.dart';
import 'package:khmer_shopping/providers/settings_provider.dart';
import 'package:khmer_shopping/widgets/empty_state.dart';
import 'package:khmer_shopping/widgets/fade_slide_in.dart';
import 'package:khmer_shopping/widgets/product_card.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  @override
  void dispose() {
    _controller.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  /// Keeps the text field in sync when the query is changed from elsewhere
  /// (e.g. tapping a category on the Home screen) and handles focus requests.
  void _syncWithProvider(SearchProvider search) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (_controller.text != search.query) {
        _controller.value = TextEditingValue(
          text: search.query,
          selection: TextSelection.collapsed(offset: search.query.length),
        );
      }
      if (search.consumeFocusRequest()) {
        _focusNode.requestFocus();
      }
    });
  }

  String _sortLabel(SortOption option) {
    switch (option) {
      case SortOption.relevance:
        return 'Default';
      case SortOption.priceLowToHigh:
        return 'Price: Low to High';
      case SortOption.priceHighToLow:
        return 'Price: High to Low';
    }
  }

  IconData? _sortIcon(SortOption option) {
    switch (option) {
      case SortOption.relevance:
        return null;
      case SortOption.priceLowToHigh:
        return Icons.arrow_upward;
      case SortOption.priceHighToLow:
        return Icons.arrow_downward;
    }
  }

  @override
  Widget build(BuildContext context) {
    final search = context.watch<SearchProvider>();
    final settings = context.watch<SettingsProvider>();
    _syncWithProvider(search);

    final results = search.results;
    final showRecent =
        search.query.trim().isEmpty && settings.recentSearches.isNotEmpty;

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: Text(
                  'Search',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
                ),
              ),
            ),

            // ---- Search field ----
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  controller: _controller,
                  focusNode: _focusNode,
                  textInputAction: TextInputAction.search,
                  onChanged: (value) =>
                      context.read<SearchProvider>().setQuery(value),
                  onSubmitted: (value) =>
                      context.read<SettingsProvider>().addRecentSearch(value),
                  decoration: InputDecoration(
                    hintText: 'Search products by name...',
                    prefixIcon: const Icon(Icons.search, color: AppColors.gold),
                    suffixIcon: search.query.isEmpty
                        ? null
                        : IconButton(
                            tooltip: 'Clear',
                            icon: const Icon(Icons.close),
                            onPressed: () {
                              _controller.clear();
                              context.read<SearchProvider>().setQuery('');
                            },
                          ),
                  ),
                ),
              ),
            ),

            // ---- Category filter ----
            SliverToBoxAdapter(
              child: SizedBox(
                height: 58,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  children: [
                    _FilterChip(
                      label: 'All',
                      selected: search.category == null,
                      onSelected: () =>
                          context.read<SearchProvider>().setCategory(null),
                    ),
                    for (final category in SampleData.categories)
                      _FilterChip(
                        label: category.name,
                        icon: category.icon,
                        selected: search.category == category.name,
                        onSelected: () => context
                            .read<SearchProvider>()
                            .setCategory(category.name),
                      ),
                  ],
                ),
              ),
            ),

            // ---- Sort ----
            SliverToBoxAdapter(
              child: SizedBox(
                height: 48,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  children: [
                    const Padding(
                      padding: EdgeInsets.only(right: 10),
                      child: Center(
                        child: Text(
                          'Sort by',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    for (final option in SortOption.values)
                      _FilterChip(
                        label: _sortLabel(option),
                        icon: _sortIcon(option),
                        selected: search.sort == option,
                        onSelected: () =>
                            context.read<SearchProvider>().setSort(option),
                      ),
                  ],
                ),
              ),
            ),

            // ---- Recent searches ----
            if (showRecent)
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'Recent searches',
                              style: TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          TextButton(
                            onPressed: () => context
                                .read<SettingsProvider>()
                                .clearRecentSearches(),
                            child: const Text('Clear'),
                          ),
                        ],
                      ),
                      Wrap(
                        spacing: 8,
                        runSpacing: 4,
                        children: [
                          for (final term in settings.recentSearches)
                            ActionChip(
                              avatar: const Icon(Icons.history, size: 16),
                              label: Text(term),
                              backgroundColor: AppColors.card,
                              side: BorderSide.none,
                              onPressed: () {
                                context.read<SearchProvider>().setQuery(term);
                              },
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

            // ---- Result count / reset ----
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${results.length} product${results.length == 1 ? '' : 's'} found',
                        style: const TextStyle(color: AppColors.textSecondary),
                      ),
                    ),
                    if (search.hasFilters || search.sort != SortOption.relevance)
                      TextButton.icon(
                        onPressed: () {
                          _controller.clear();
                          context.read<SearchProvider>().clearAll();
                        },
                        icon: const Icon(Icons.restart_alt, size: 18),
                        label: const Text('Reset'),
                      ),
                  ],
                ),
              ),
            ),

            // ---- Results ----
            if (results.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: EmptyState(
                  icon: Icons.search_off,
                  title: 'No products found',
                  message:
                      'Try a different keyword or choose another category.',
                  buttonLabel: 'Clear filters',
                  onPressed: () {
                    _controller.clear();
                    context.read<SearchProvider>().clearAll();
                  },
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                sliver: SliverGrid(
                  gridDelegate: productGridDelegate(context),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => FadeSlideIn(
                      key: ValueKey<String>('search-${results[index].id}'),
                      index: index,
                      child: ProductCard(product: results[index]),
                    ),
                    childCount: results.length,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onSelected,
    this.icon,
  });

  final String label;
  final IconData? icon;
  final bool selected;
  final VoidCallback onSelected;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        showCheckmark: false,
        selected: selected,
        onSelected: (_) => onSelected(),
        avatar: icon == null
            ? null
            : Icon(
                icon,
                size: 16,
                color: selected ? AppColors.black : AppColors.gold,
              ),
        label: Text(label),
        labelStyle: TextStyle(
          color: selected ? AppColors.black : AppColors.textPrimary,
          fontWeight: FontWeight.w700,
          fontSize: 13,
        ),
        backgroundColor: AppColors.card,
        selectedColor: AppColors.gold,
        side: BorderSide.none,
        shape: const StadiumBorder(),
      ),
    );
  }
}
