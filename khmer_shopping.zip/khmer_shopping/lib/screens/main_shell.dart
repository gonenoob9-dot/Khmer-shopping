import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/providers/nav_provider.dart';
import 'package:khmer_shopping/screens/cart_screen.dart';
import 'package:khmer_shopping/screens/home_screen.dart';
import 'package:khmer_shopping/screens/profile_screen.dart';
import 'package:khmer_shopping/screens/search_screen.dart';
import 'package:khmer_shopping/screens/wishlist_screen.dart';

/// Hosts the five main tabs with a bottom navigation bar.
class MainShell extends StatelessWidget {
  const MainShell({super.key});

  static const List<Widget> _pages = [
    HomeScreen(),
    SearchScreen(),
    WishlistScreen(),
    CartScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final index = context.select<NavProvider, int>((n) => n.index);
    final cartCount = context.select<CartProvider, int>((c) => c.itemCount);
    final favCount = context.select<FavoritesProvider, int>((f) => f.count);

    return PopScope(
      canPop: index == 0,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) context.read<NavProvider>().setIndex(0);
      },
      child: Scaffold(
        body: IndexedStack(index: index, children: _pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) =>
              context.read<NavProvider>().setIndex(value),
          destinations: [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home_rounded),
              label: 'Home',
            ),
            NavigationDestination(
              icon: Icon(Icons.search),
              selectedIcon: Icon(Icons.search_rounded),
              label: 'Search',
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: favCount > 0,
                label: Text('$favCount'),
                child: Icon(Icons.favorite_border),
              ),
              selectedIcon: Badge(
                isLabelVisible: favCount > 0,
                label: Text('$favCount'),
                child: Icon(Icons.favorite),
              ),
              label: 'Wishlist',
            ),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: cartCount > 0,
                label: Text('$cartCount'),
                child: Icon(Icons.shopping_bag_outlined),
              ),
              selectedIcon: Badge(
                isLabelVisible: cartCount > 0,
                label: Text('$cartCount'),
                child: Icon(Icons.shopping_bag),
              ),
              label: 'Cart',
            ),
            NavigationDestination(
              icon: Icon(Icons.person_outline),
              selectedIcon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}
