import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/routes.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/models/cart_item.dart';
import 'package:khmer_shopping/models/user_profile.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/orders_provider.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/screens/order_success_screen.dart';
import 'package:khmer_shopping/widgets/gold_button.dart';
import 'package:khmer_shopping/widgets/product_image.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _addressController;
  final TextEditingController _noteController = TextEditingController();

  // Snapshot of the cart so the summary stays stable after the cart is cleared.
  late final List<CartItem> _items;
  late final double _subtotal;
  late final double _deliveryFee;
  late final double _total;

  bool _saveToProfile = true;
  bool _placing = false;

  @override
  void initState() {
    super.initState();
    final cart = context.read<CartProvider>();
    final profile = context.read<ProfileProvider>().profile;
    _items = cart.items;
    _subtotal = cart.subtotal;
    _deliveryFee = cart.deliveryFee;
    _total = cart.total;
    _nameController = TextEditingController(text: profile.name);
    _phoneController = TextEditingController(text: profile.phone);
    _addressController = TextEditingController(text: profile.address);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _confirmOrder() async {
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;
    if (_items.isEmpty) return;

    final orders = context.read<OrdersProvider>();
    final cart = context.read<CartProvider>();
    final profileProvider = context.read<ProfileProvider>();
    final navigator = Navigator.of(context);

    setState(() => _placing = true);
    // Short delay to simulate placing the order.
    await Future<void>.delayed(Duration(milliseconds: 1000));
    if (!mounted) return;

    final name = _nameController.text.trim();
    final phone = _phoneController.text.trim();
    final address = _addressController.text.trim();

    final order = orders.createOrder(
      items: _items,
      subtotal: _subtotal,
      deliveryFee: _deliveryFee,
      total: _total,
      customerName: name,
      phone: phone,
      address: address,
      note: _noteController.text.trim(),
    );

    if (_saveToProfile) {
      profileProvider.update(
        UserProfile(name: name, phone: phone, address: address),
      );
    }

    navigator.pushReplacement(
      slideFadeRoute<void>(OrderSuccessScreen(order: order)),
    );
    cart.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Checkout')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            _SectionTitle(icon: Icons.location_on, title: 'Delivery Information'),
            SizedBox(height: 12),
            TextFormField(
              controller: _nameController,
              textInputAction: TextInputAction.next,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(
                labelText: 'Customer name',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: (value) {
                if (value == null || value.trim().length < 2) {
                  return 'Please enter your name';
                }
                return null;
              },
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                labelText: 'Phone number',
                hintText: 'e.g. 012 345 678',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
              validator: (value) {
                final text = (value ?? '').trim();
                if (!RegExp(r'^\+?[0-9 ]{8,15}$').hasMatch(text)) {
                  return 'Enter a valid phone number (8-15 digits)';
                }
                return null;
              },
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _addressController,
              keyboardType: TextInputType.multiline,
              textInputAction: TextInputAction.next,
              minLines: 2,
              maxLines: 3,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: 'Delivery address',
                hintText: 'House no., street, district, city',
                prefixIcon: Icon(Icons.home_outlined),
              ),
              validator: (value) {
                if (value == null || value.trim().length < 6) {
                  return 'Please enter your full delivery address';
                }
                return null;
              },
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _noteController,
              textInputAction: TextInputAction.done,
              decoration: InputDecoration(
                labelText: 'Note for courier (optional)',
                prefixIcon: Icon(Icons.edit_note),
              ),
            ),
            SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text('Save these details to my profile'),
              value: _saveToProfile,
              onChanged: (value) => setState(() => _saveToProfile = value),
            ),
            SizedBox(height: 12),
            _SectionTitle(icon: Icons.payments_outlined, title: 'Payment Method'),
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.gold, width: 1.4),
              ),
              child: Row(
                children: [
                  Icon(Icons.local_shipping_outlined, color: AppColors.gold),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Cash on Delivery',
                          style: TextStyle(fontWeight: FontWeight.w800),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Demo payment - pay the courier when your order arrives.',
                          style: TextStyle(
                            color: AppColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 8),
                  Icon(Icons.check_circle, color: AppColors.gold),
                ],
              ),
            ),
            SizedBox(height: 24),
            _SectionTitle(icon: Icons.receipt_long_outlined, title: 'Order Summary'),
            SizedBox(height: 12),
            Container(
              padding: EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  for (final item in _items)
                    Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: SizedBox(
                              width: 48,
                              height: 48,
                              child: ProductImage(product: item.product),
                            ),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.product.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 13.5,
                                  ),
                                ),
                                Text(
                                  '${formatPrice(item.product.finalPrice)} x ${item.quantity}',
                                  style: TextStyle(
                                    color: AppColors.textSecondary,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 8),
                          Text(
                            formatPrice(item.lineTotal),
                            style: TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                    ),
                  Divider(),
                  SizedBox(height: 12),
                  _TotalRow(label: 'Subtotal', value: formatPrice(_subtotal)),
                  SizedBox(height: 6),
                  _TotalRow(
                    label: 'Delivery',
                    value: _deliveryFee == 0 ? 'FREE' : formatPrice(_deliveryFee),
                    valueColor: _deliveryFee == 0 ? AppColors.success : null,
                  ),
                  SizedBox(height: 10),
                  _TotalRow(
                    label: 'Total',
                    value: formatPrice(_total),
                    large: true,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(
            top: BorderSide(color: AppColors.line),
          ),
        ),
        child: SafeArea(
          top: false,
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: GoldButton(
              label: 'Confirm Order  -  ${formatPrice(_total)}',
              icon: Icons.check_circle_outline,
              loading: _placing,
              onPressed: _items.isEmpty ? null : _confirmOrder,
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.icon, required this.title});

  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: AppColors.gold, size: 20),
        SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
      ],
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({
    required this.label,
    required this.value,
    this.large = false,
    this.valueColor,
  });

  final String label;
  final String value;
  final bool large;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              fontSize: large ? 17 : 14,
              fontWeight: large ? FontWeight.w800 : FontWeight.w500,
              color: large ? AppColors.textPrimary : AppColors.textSecondary,
            ),
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: large ? 20 : 14,
            fontWeight: FontWeight.w800,
            color: valueColor ?? (large ? AppColors.gold : AppColors.textPrimary),
          ),
        ),
      ],
    );
  }
}
