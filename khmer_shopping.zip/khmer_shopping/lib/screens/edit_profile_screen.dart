import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/models/user_profile.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/widgets/gold_button.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _address;

  @override
  void initState() {
    super.initState();
    final profile = context.read<ProfileProvider>().profile;
    _name = TextEditingController(text: profile.name);
    _phone = TextEditingController(text: profile.phone);
    _address = TextEditingController(text: profile.address);
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  void _save() {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    FocusScope.of(context).unfocus();
    final provider = context.read<ProfileProvider>();
    final messenger = ScaffoldMessenger.of(context);
    provider.update(
      UserProfile(
        name: _name.text.trim(),
        phone: _phone.text.trim(),
        address: _address.text.trim(),
      ),
    );
    Navigator.of(context).pop();
    showSnackOn(messenger, 'Profile saved');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Customer Information')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                labelText: 'Full name',
                prefixIcon: Icon(Icons.person_outline),
              ),
              validator: (value) => (value == null || value.trim().length < 2)
                  ? 'Please enter your name'
                  : null,
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              textInputAction: TextInputAction.next,
              decoration: InputDecoration(
                labelText: 'Phone number',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
              validator: (value) {
                final text = (value ?? '').trim();
                if (text.isEmpty) return null; // optional here
                return RegExp(r'^\+?[0-9 ]{8,15}$').hasMatch(text)
                    ? null
                    : 'Enter a valid phone number (8-15 digits)';
              },
            ),
            SizedBox(height: 12),
            TextFormField(
              controller: _address,
              minLines: 2,
              maxLines: 3,
              keyboardType: TextInputType.multiline,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: 'Delivery address',
                prefixIcon: Icon(Icons.home_outlined),
              ),
            ),
            SizedBox(height: 24),
            GoldButton(
              label: 'Save Changes',
              icon: Icons.save_outlined,
              onPressed: _save,
            ),
          ],
        ),
      ),
    );
  }
}
