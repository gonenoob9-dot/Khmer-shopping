import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/providers/favorites_provider.dart';
import 'package:khmer_shopping/providers/profile_provider.dart';
import 'package:khmer_shopping/providers/search_provider.dart';
import 'package:khmer_shopping/providers/theme_provider.dart';
import 'package:khmer_shopping/widgets/app_logo.dart';
import 'package:khmer_shopping/widgets/cart_icon_button.dart';
import 'package:khmer_shopping/widgets/category_tile.dart';
import 'package:khmer_shopping/widgets/fade_slide_in.dart';
import 'package:khmer_shopping/widgets/product_card.dart';
import 'package:khmer_shopping/widgets/promo_banner.dart';
import 'package:khmer_shopping/widgets/section_header.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _openSearch(BuildContext context, {String? category, bool focus = false}) {
    final search = context.read<SearchProvider>();
    search.clearAll();
    if (category != null) search.setCategory(category);
    if (focus) search.requestFocus();
    AppNavigator.goToTab(AppTabs.search);
  }

  @override
  Widget build(BuildContext context) {
    final name = context.select<ProfileProvider, String>(
      (p) => p.profile.displayName,
    );
    final favCount = context.select<FavoritesProvider, int>((f) => f.count);
    final width = MediaQuery.sizeOf(context).width;
    final featured = SampleData.featured;
    final popular = SampleData.popular;

    final featuredCardWidth = (width * 0.44).clamp(150.0, 200.0).toDouble();
    final featuredHeight = productCardHeight(context, featuredCardWidth);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            // ---- Header: logo, name, wishlist & cart ----
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 8, 0),
                child: Row(
                  children: [
                    AppLogo(size: 44),
                    SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ShaderMask(
                            blendMode: BlendMode.srcIn,
                            shaderCallback: (bounds) =>
                                AppColors.goldGradient.createShader(bounds),
                            child: Text(
                              AppConfig.appName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 21,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          Text(
                            'Welcome, $name',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: AppColors.textSecondary,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Light / dark mode',
                      onPressed: () => context.read<ThemeProvider>().toggle(),
                      icon: Icon(
                        AppColors.isLight
                            ? Icons.dark_mode_outlined
                            : Icons.light_mode_outlined,
                      ),
                    ),
                    IconButton(
                      tooltip: 'Wishlist',
                      onPressed: () => AppNavigator.goToTab(AppTabs.wishlist),
                      icon: Badge(
                        isLabelVisible: favCount > 0,
                        label: Text('$favCount'),
                        child: Icon(Icons.favorite_border),
                      ),
                    ),
                    CartIconButton(),
                  ],
                ),
              ),
            ),

            // ---- Search bar ----
            SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 16),
                child: Material(
                  color: AppColors.card,
                  borderRadius: BorderRadius.circular(16),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => _openSearch(context, focus: true),
                    child: Container(
                      height: 52,
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppColors.gold.withValues(alpha: 0.25),
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.search, color: AppColors.gold),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'Search products...',
                              style: TextStyle(color: AppColors.textSecondary),
                            ),
                          ),
                          Icon(Icons.tune, color: AppColors.textSecondary),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            // ---- Promotional banner ----
            SliverToBoxAdapter(
              child: PromoBanner(
                onTap: (item) => _openSearch(context, category: item.category),
              ),
            ),

            // ---- Categories ----
            SliverToBoxAdapter(child: SectionHeader(title: 'Categories')),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 96,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  itemCount: SampleData.categories.length,
                  separatorBuilder: (context, index) =>
                      SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final category = SampleData.categories[index];
                    return FadeSlideIn(
                      index: index,
                      offset: 16,
                      child: CategoryTile(
                        category: category,
                        onTap: () =>
                            _openSearch(context, category: category.name),
                      ),
                    );
                  },
                ),
              ),
            ),

            // ---- Featured products ----
            SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Featured Products',
                actionLabel: 'See all',
                onAction: () => _openSearch(context),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: featuredHeight,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  itemCount: featured.length,
                  separatorBuilder: (context, index) =>
                      SizedBox(width: 12),
                  itemBuilder: (context, index) => FadeSlideIn(
                    index: index,
                    child: SizedBox(
                      width: featuredCardWidth,
                      child: ProductCard(product: featured[index]),
                    ),
                  ),
                ),
              ),
            ),

            // ---- Popular products ----
            SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Popular Products',
                actionLabel: 'See all',
                onAction: () => _openSearch(context),
              ),
            ),
            SliverPadding(
              padding: EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                gridDelegate: productGridDelegate(context),
                delegate: SliverChildBuilderDelegate(
                  (context, index) => FadeSlideIn(
                    index: index,
                    child: ProductCard(product: popular[index]),
                  ),
                  childCount: popular.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
