import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/core/ui_helpers.dart';
import 'package:khmer_shopping/data/sample_data.dart';
import 'package:khmer_shopping/models/order.dart';
import 'package:khmer_shopping/providers/cart_provider.dart';
import 'package:khmer_shopping/providers/orders_provider.dart';
import 'package:khmer_shopping/widgets/empty_state.dart';
import 'package:khmer_shopping/widgets/fade_slide_in.dart';

class OrderHistoryScreen extends StatelessWidget {
  const OrderHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrdersProvider>().orders;

    return Scaffold(
      appBar: AppBar(title: const Text('Order History')),
      body: orders.isEmpty
          ? EmptyState(
              icon: Icons.receipt_long_outlined,
              title: 'No orders yet',
              message: 'When you place an order it will show up here.',
              buttonLabel: 'Start shopping',
              onPressed: () => AppNavigator.goToTab(AppTabs.home),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
              itemCount: orders.length,
              itemBuilder: (context, index) => FadeSlideIn(
                index: index,
                child: _OrderCard(order: orders[index]),
              ),
            ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  const _OrderCard({required this.order});

  final Order order;

  void _reorder(BuildContext context) {
    final cart = context.read<CartProvider>();
    var added = 0;
    for (final item in order.items) {
      final product = SampleData.byId(item.productId);
      if (product != null) {
        cart.add(product, quantity: item.quantity);
        added += item.quantity;
      }
    }
    if (added == 0) {
      showAppSnack(
        context,
        'These products are no longer available',
        icon: Icons.info_outline,
      );
      return;
    }
    AppNavigator.goToTab(AppTabs.cart);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Material(
          color: AppColors.card,
          child: Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              shape: const Border(),
              collapsedShape: const Border(),
              tilePadding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              iconColor: AppColors.gold,
              collapsedIconColor: AppColors.textSecondary,
              title: Row(
                children: [
                  Expanded(
                    child: Text(
                      order.id,
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.success.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      order.status,
                      style: const TextStyle(
                        color: AppColors.success,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  '${formatDateTime(order.createdAt)}\n${order.itemCount} item${order.itemCount == 1 ? '' : 's'}  -  ${formatPrice(order.total)}',
                  style: const TextStyle(
                    color: AppColors.textSecondary,
                    fontSize: 12.5,
                    height: 1.4,
                  ),
                ),
              ),
              children: [
                const Divider(),
                const SizedBox(height: 12),
                for (final item in order.items)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${item.quantity} x ${item.name}',
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          formatPrice(item.lineTotal),
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                const SizedBox(height: 10),
                const Divider(),
                const SizedBox(height: 10),
                _line('Subtotal', formatPrice(order.subtotal)),
                _line(
                  'Delivery',
                  order.deliveryFee == 0 ? 'FREE' : formatPrice(order.deliveryFee),
                ),
                _line('Total', formatPrice(order.total), bold: true),
                const SizedBox(height: 10),
                _line('Payment', order.paymentMethod),
                _line('Name', order.customerName),
                _line('Phone', order.phone),
                _line('Address', order.address),
                if (order.note.isNotEmpty) _line('Note', order.note),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () => _reorder(context),
                    icon: const Icon(Icons.replay),
                    label: const Text('Reorder'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _line(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              label,
              style: const TextStyle(color: AppColors.textSecondary),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
                color: bold ? AppColors.gold : AppColors.textPrimary,
                fontSize: bold ? 16 : 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
