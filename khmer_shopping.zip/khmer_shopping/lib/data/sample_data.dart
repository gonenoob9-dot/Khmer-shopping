import 'package:flutter/material.dart';

import 'package:khmer_shopping/data/image_overrides.dart';
import 'package:khmer_shopping/models/product.dart';
import 'package:khmer_shopping/models/product_category.dart';

/// Local sample catalog used by Version 1 (no backend required).
class SampleData {
  SampleData._();

  static const List<ProductCategory> categories = [
    ProductCategory(
      name: 'Electronics',
      icon: Icons.devices,
      tint: Color(0xFF1F2A3A),
    ),
    ProductCategory(
      name: 'Fashion',
      icon: Icons.checkroom,
      tint: Color(0xFF3A2A1F),
    ),
    ProductCategory(
      name: 'Beauty',
      icon: Icons.spa,
      tint: Color(0xFF3A1F2E),
    ),
    ProductCategory(
      name: 'Home',
      icon: Icons.chair,
      tint: Color(0xFF1F3A2E),
    ),
    ProductCategory(
      name: 'Sports',
      icon: Icons.fitness_center,
      tint: Color(0xFF3A361F),
    ),
    ProductCategory(
      name: 'Accessories',
      icon: Icons.watch,
      tint: Color(0xFF2E2E2E),
    ),
  ];

  static const List<Product> products = [
    // ---------------- Electronics ----------------
    Product(
      id: 'e1',
      name: 'Aurora Wireless Headphones',
      description:
          'Over-ear wireless headphones with active noise cancelling, 40-hour battery life and plush memory-foam ear cushions. Crystal clear calls and deep, balanced sound for work, travel and everything between.',
      category: 'Electronics',
      price: 129,
      discountPercent: 25,
      rating: 4.8,
      reviewCount: 1240,
      icon: Icons.headphones,
      isFeatured: true,
      isPopular: true,
    ),
    Product(
      id: 'e2',
      name: 'Nova Pro Smartphone 256GB',
      description:
          'Flagship smartphone with a 6.7" AMOLED display, 256GB storage, all-day battery and a triple-lens camera system that shines in low light. Fast charging included.',
      category: 'Electronics',
      price: 899,
      discountPercent: 10,
      rating: 4.7,
      reviewCount: 860,
      icon: Icons.smartphone,
      isFeatured: true,
    ),
    Product(
      id: 'e3',
      name: 'Zenith Ultrabook 14"',
      description:
          'Slim 14-inch ultrabook with a bright 2K display, 16GB RAM and a 512GB SSD. Lightweight aluminium body with up to 14 hours of battery life.',
      category: 'Electronics',
      price: 1249,
      discountPercent: 15,
      rating: 4.6,
      reviewCount: 430,
      icon: Icons.laptop_mac,
      isPopular: true,
    ),
    Product(
      id: 'e4',
      name: 'Pulse Bluetooth Speaker',
      description:
          'Portable waterproof speaker with 360-degree sound and punchy bass. 20 hours of playtime and a rugged, drop-resistant design for the beach or the road.',
      category: 'Electronics',
      price: 59,
      rating: 4.5,
      reviewCount: 2100,
      icon: Icons.speaker,
      isPopular: true,
    ),
    Product(
      id: 'e5',
      name: 'Lumina Mirrorless Camera',
      description:
          '24MP mirrorless camera with fast autofocus, 4K video and in-body stabilisation. Includes an 18-55mm kit lens - perfect for creators and travellers.',
      category: 'Electronics',
      price: 749,
      discountPercent: 20,
      rating: 4.9,
      reviewCount: 310,
      icon: Icons.camera_alt,
      isFeatured: true,
    ),
    Product(
      id: 'e6',
      name: 'Mechanical Gaming Keyboard',
      description:
          'Hot-swappable mechanical keyboard with tactile switches, per-key gold backlighting and a solid aluminium frame. Built for long gaming and typing sessions.',
      category: 'Electronics',
      price: 89,
      discountPercent: 30,
      rating: 4.4,
      reviewCount: 975,
      icon: Icons.keyboard,
      isPopular: true,
    ),

    // ---------------- Fashion ----------------
    Product(
      id: 'f1',
      name: 'Classic Leather Jacket',
      description:
          'Timeless biker jacket in soft genuine leather with a quilted lining and brushed gold hardware. A statement piece that gets better with every wear.',
      category: 'Fashion',
      price: 189,
      discountPercent: 20,
      rating: 4.7,
      reviewCount: 520,
      icon: Icons.checkroom,
      isFeatured: true,
    ),
    Product(
      id: 'f2',
      name: 'Urban Street Sneakers',
      description:
          'Comfortable everyday sneakers with a cushioned insole, breathable upper and durable grip sole. Clean minimal design that pairs with anything.',
      category: 'Fashion',
      price: 99,
      discountPercent: 15,
      rating: 4.6,
      reviewCount: 1830,
      icon: Icons.directions_walk,
      isPopular: true,
    ),
    Product(
      id: 'f3',
      name: 'Tailored Slim Blazer',
      description:
          'Modern slim-fit blazer in a premium wool blend. Half-lined for breathability with a sharp structured shoulder - from the office to evening events.',
      category: 'Fashion',
      price: 149,
      rating: 4.5,
      reviewCount: 270,
      icon: Icons.dry_cleaning,
    ),
    Product(
      id: 'f4',
      name: 'Premium Cotton Hoodie',
      description:
          'Heavyweight 100% brushed cotton hoodie with a relaxed fit, double-layer hood and ribbed cuffs. Warm, soft and built to last.',
      category: 'Fashion',
      price: 49,
      discountPercent: 10,
      rating: 4.8,
      reviewCount: 2460,
      icon: Icons.checkroom,
      isPopular: true,
    ),

    // ---------------- Beauty ----------------
    Product(
      id: 'b1',
      name: 'Gold Radiance Serum',
      description:
          'Lightweight vitamin C serum with hyaluronic acid and 24k gold flecks. Brightens, hydrates and gives skin a healthy, luminous glow.',
      category: 'Beauty',
      price: 45,
      discountPercent: 20,
      rating: 4.8,
      reviewCount: 1410,
      icon: Icons.water_drop,
      isFeatured: true,
    ),
    Product(
      id: 'b2',
      name: 'Royal Oud Perfume 100ml',
      description:
          'A rich, long-lasting eau de parfum with warm oud, amber and a touch of vanilla. Elegant, confident and unforgettable.',
      category: 'Beauty',
      price: 119,
      rating: 4.9,
      reviewCount: 780,
      icon: Icons.local_florist,
      isFeatured: true,
      isPopular: true,
    ),
    Product(
      id: 'b3',
      name: 'Hydra Glow Face Cream',
      description:
          'Deeply moisturising day and night cream with ceramides and aloe. Non-greasy formula that leaves skin soft, smooth and refreshed.',
      category: 'Beauty',
      price: 32,
      discountPercent: 15,
      rating: 4.5,
      reviewCount: 940,
      icon: Icons.face_retouching_natural,
      isPopular: true,
    ),
    Product(
      id: 'b4',
      name: 'Silk Matte Lipstick Set',
      description:
          'Set of four velvety matte lipsticks in modern neutral and berry shades. Comfortable, highly pigmented colour that lasts all day.',
      category: 'Beauty',
      price: 28,
      discountPercent: 25,
      rating: 4.6,
      reviewCount: 650,
      icon: Icons.brush,
    ),

    // ---------------- Home ----------------
    Product(
      id: 'h1',
      name: 'Nordic Lounge Chair',
      description:
          'Scandinavian-inspired lounge chair with a solid oak frame and thick cushioned seat. Comfortable, compact and a beautiful accent for any room.',
      category: 'Home',
      price: 249,
      discountPercent: 20,
      rating: 4.7,
      reviewCount: 340,
      icon: Icons.chair,
      isFeatured: true,
    ),
    Product(
      id: 'h2',
      name: 'Smart Espresso Machine',
      description:
          '15-bar espresso machine with a built-in grinder, milk frother and app control. Barista-quality coffee at the touch of a button.',
      category: 'Home',
      price: 329,
      discountPercent: 10,
      rating: 4.8,
      reviewCount: 590,
      icon: Icons.coffee_maker,
      isPopular: true,
    ),
    Product(
      id: 'h3',
      name: 'Ambient LED Floor Lamp',
      description:
          'Dimmable floor lamp with warm-to-cool light, remote control and a minimalist gold-finish stem. Sets the perfect mood in seconds.',
      category: 'Home',
      price: 69,
      discountPercent: 15,
      rating: 4.4,
      reviewCount: 410,
      icon: Icons.lightbulb,
      isPopular: true,
    ),
    Product(
      id: 'h4',
      name: 'Luxury Cotton Bedding Set',
      description:
          'Four-piece 400-thread-count Egyptian cotton bedding set. Breathable, silky smooth and available in a timeless charcoal tone.',
      category: 'Home',
      price: 119,
      rating: 4.6,
      reviewCount: 380,
      icon: Icons.bed,
    ),

    // ---------------- Sports ----------------
    Product(
      id: 's1',
      name: 'Pro Running Shoes',
      description:
          'Lightweight performance running shoes with responsive foam cushioning and a breathable knit upper. Designed for daily miles and race day.',
      category: 'Sports',
      price: 119,
      discountPercent: 25,
      rating: 4.7,
      reviewCount: 1560,
      icon: Icons.directions_run,
      isFeatured: true,
      isPopular: true,
    ),
    Product(
      id: 's2',
      name: 'Adjustable Dumbbell Set',
      description:
          'Space-saving adjustable dumbbells from 2 to 24 kg with a quick-change dial. A full home gym in a single compact set.',
      category: 'Sports',
      price: 159,
      discountPercent: 10,
      rating: 4.6,
      reviewCount: 430,
      icon: Icons.fitness_center,
    ),
    Product(
      id: 's3',
      name: 'Premium Yoga Mat',
      description:
          'Extra-thick, non-slip yoga mat made from eco-friendly material. Comfortable cushioning and excellent grip for every pose.',
      category: 'Sports',
      price: 35,
      rating: 4.5,
      reviewCount: 1120,
      icon: Icons.self_improvement,
      isPopular: true,
    ),
    Product(
      id: 's4',
      name: 'Mountain Hiking Backpack',
      description:
          '40L water-resistant hiking backpack with padded straps, ventilated back panel and a built-in rain cover. Ready for any trail.',
      category: 'Sports',
      price: 79,
      discountPercent: 20,
      rating: 4.7,
      reviewCount: 690,
      icon: Icons.hiking,
    ),

    // ---------------- Accessories ----------------
    Product(
      id: 'a1',
      name: 'Chronos Gold Watch',
      description:
          'Elegant stainless steel watch with a gold-tone case, sapphire-coated glass and a Japanese quartz movement. Water resistant to 50 metres.',
      category: 'Accessories',
      price: 299,
      discountPercent: 15,
      rating: 4.9,
      reviewCount: 860,
      icon: Icons.watch,
      isFeatured: true,
    ),
    Product(
      id: 'a2',
      name: 'Aviator Sunglasses',
      description:
          'Classic aviator sunglasses with polarised lenses, UV400 protection and a lightweight gold metal frame. Includes a protective case.',
      category: 'Accessories',
      price: 79,
      discountPercent: 20,
      rating: 4.5,
      reviewCount: 1190,
      icon: Icons.wb_sunny,
    ),
    Product(
      id: 'a3',
      name: 'Leather Bifold Wallet',
      description:
          'Slim full-grain leather wallet with RFID protection, six card slots and a bill compartment. Handcrafted to age beautifully.',
      category: 'Accessories',
      price: 55,
      rating: 4.6,
      reviewCount: 1530,
      icon: Icons.account_balance_wallet,
      isPopular: true,
    ),
    Product(
      id: 'a4',
      name: 'Minimal Gold Necklace',
      description:
          '18k gold-plated minimalist pendant necklace on a fine adjustable chain. Hypoallergenic and tarnish resistant for everyday elegance.',
      category: 'Accessories',
      price: 89,
      discountPercent: 10,
      rating: 4.8,
      reviewCount: 720,
      icon: Icons.diamond,
      isFeatured: true,
    ),
  ];


  /// Search keywords used to fetch an automatic stock photo per product.
  static const Map<String, String> _imageKeywords = {
    'e1': 'headphones',
    'e2': 'smartphone',
    'e3': 'laptop',
    'e4': 'speaker',
    'e5': 'camera',
    'e6': 'keyboard',
    'f1': 'leather,jacket',
    'f2': 'sneakers',
    'f3': 'blazer,suit',
    'f4': 'hoodie',
    'b1': 'serum,skincare',
    'b2': 'perfume',
    'b3': 'face,cream',
    'b4': 'lipstick',
    'h1': 'armchair',
    'h2': 'espresso,machine',
    'h3': 'floor,lamp',
    'h4': 'bedding,bed',
    's1': 'running,shoes',
    's2': 'dumbbell',
    's3': 'yoga,mat',
    's4': 'backpack,hiking',
    'a1': 'wristwatch',
    'a2': 'sunglasses',
    'a3': 'wallet',
    'a4': 'necklace,gold',
  };

  /// Picture link for a product: your own link from image_overrides.dart, or
  /// an automatic photo for the product keyword. Returns null if none.
  static String? imageUrlFor(Product product) {
    final custom = kImageOverrides[product.id];
    if (custom != null && custom.trim().isNotEmpty) return custom.trim();
    final keywords = _imageKeywords[product.id];
    if (keywords == null) return null;
    final lock = products.indexWhere((p) => p.id == product.id) + 11;
    return 'https://loremflickr.com/600/600/$keywords?lock=$lock';
  }

  static Product? byId(String id) {
    for (final product in products) {
      if (product.id == id) return product;
    }
    return null;
  }

  static ProductCategory categoryOf(String name) {
    return categories.firstWhere(
      (c) => c.name == name,
      orElse: () => categories.first,
    );
  }

  static List<Product> get featured =>
      products.where((p) => p.isFeatured).toList();

  static List<Product> get popular =>
      products.where((p) => p.isPopular).toList();

  static List<Product> related(Product product, {int limit = 6}) {
    return products
        .where((p) => p.category == product.category && p.id != product.id)
        .take(limit)
        .toList();
  }
}
