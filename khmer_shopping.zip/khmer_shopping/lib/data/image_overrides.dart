/// Put your own product pictures here.
///
/// Format:  'product id': 'direct image link',
///
/// The link must be a DIRECT picture link (it opens only the picture and
/// usually ends with .jpg / .jpeg / .png / .webp). On Android Chrome: long-press
/// the picture > "Copy image address" (or "Open image in new tab" and copy the
/// address). Links to a Google Images results page do not work.
///
/// Product ids: e1-e6 Electronics, f1-f4 Fashion, b1-b4 Beauty, h1-h4 Home,
/// s1-s4 Sports, a1-a4 Accessories.
///
/// Products without a link here use an automatic photo for their keyword (see
/// SampleData). If the phone is offline or a link is broken, the app shows the
/// gold artwork instead.
const Map<String, String> kImageOverrides = {
  // 'e1': 'https://example.com/headphones.jpg',
};
