class UserProfile {
  const UserProfile({this.name = '', this.phone = '', this.address = ''});

  final String name;
  final String phone;
  final String address;

  bool get isEmpty => name.isEmpty && phone.isEmpty && address.isEmpty;

  String get displayName => name.trim().isEmpty ? 'Guest' : name.trim();

  String get initials {
    final parts =
        name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return 'G';
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts.first.substring(0, 1) + parts.last.substring(0, 1))
        .toUpperCase();
  }

  UserProfile copyWith({String? name, String? phone, String? address}) {
    return UserProfile(
      name: name ?? this.name,
      phone: phone ?? this.phone,
      address: address ?? this.address,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'phone': phone,
        'address': address,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) => UserProfile(
        name: (json['name'] ?? '') as String,
        phone: (json['phone'] ?? '') as String,
        address: (json['address'] ?? '') as String,
      );
}
