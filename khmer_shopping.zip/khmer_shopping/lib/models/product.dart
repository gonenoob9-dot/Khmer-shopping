import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/formatters.dart';

class Product {
  const Product({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    required this.icon,
    this.discountPercent = 0,
    this.rating = 4.5,
    this.reviewCount = 0,
    this.isFeatured = false,
    this.isPopular = false,
  });

  final String id;
  final String name;
  final String description;
  final String category;

  /// Original (list) price in USD.
  final double price;
  final IconData icon;
  final int discountPercent;
  final double rating;
  final int reviewCount;
  final bool isFeatured;
  final bool isPopular;

  bool get hasDiscount => discountPercent > 0;

  /// Price after discount, in USD.
  double get finalPrice => roundMoney(price * (100 - discountPercent) / 100);

  double get savings => roundMoney(price - finalPrice);
}
