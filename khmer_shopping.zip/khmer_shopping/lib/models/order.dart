class OrderItem {
  const OrderItem({
    required this.productId,
    required this.name,
    required this.unitPrice,
    required this.quantity,
  });

  final String productId;
  final String name;
  final double unitPrice;
  final int quantity;

  double get lineTotal => unitPrice * quantity;

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'unitPrice': unitPrice,
        'quantity': quantity,
      };

  factory OrderItem.fromJson(Map<String, dynamic> json) => OrderItem(
        productId: json['productId'] as String,
        name: json['name'] as String,
        unitPrice: (json['unitPrice'] as num).toDouble(),
        quantity: (json['quantity'] as num).toInt(),
      );
}

class Order {
  const Order({
    required this.id,
    required this.createdAt,
    required this.items,
    required this.subtotal,
    required this.deliveryFee,
    required this.total,
    required this.customerName,
    required this.phone,
    required this.address,
    this.note = '',
    this.paymentMethod = 'Cash on Delivery',
    this.status = 'Processing',
  });

  final String id;
  final DateTime createdAt;
  final List<OrderItem> items;
  final double subtotal;
  final double deliveryFee;
  final double total;
  final String customerName;
  final String phone;
  final String address;
  final String note;
  final String paymentMethod;
  final String status;

  int get itemCount => items.fold(0, (sum, item) => sum + item.quantity);

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'items': items.map((e) => e.toJson()).toList(),
        'subtotal': subtotal,
        'deliveryFee': deliveryFee,
        'total': total,
        'customerName': customerName,
        'phone': phone,
        'address': address,
        'note': note,
        'paymentMethod': paymentMethod,
        'status': status,
      };

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json['id'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        items: (json['items'] as List<dynamic>)
            .map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
            .toList(),
        subtotal: (json['subtotal'] as num).toDouble(),
        deliveryFee: (json['deliveryFee'] as num).toDouble(),
        total: (json['total'] as num).toDouble(),
        customerName: json['customerName'] as String,
        phone: json['phone'] as String,
        address: json['address'] as String,
        note: (json['note'] ?? '') as String,
        paymentMethod: (json['paymentMethod'] ?? 'Cash on Delivery') as String,
        status: (json['status'] ?? 'Processing') as String,
      );
}
