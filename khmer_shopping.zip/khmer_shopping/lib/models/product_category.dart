import 'package:flutter/material.dart';

class ProductCategory {
  const ProductCategory({
    required this.name,
    required this.icon,
    required this.tint,
  });

  final String name;
  final IconData icon;

  /// Dark tint used for the product artwork gradient of this category.
  final Color tint;
}
