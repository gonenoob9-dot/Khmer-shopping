import 'package:khmer_shopping/core/formatters.dart';
import 'package:khmer_shopping/models/product.dart';

class CartItem {
  const CartItem({required this.product, required this.quantity});

  final Product product;
  final int quantity;

  double get lineTotal => roundMoney(product.finalPrice * quantity);
}
