import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/providers/theme_provider.dart';
import 'package:khmer_shopping/screens/splash_screen.dart';

class KhmerShoppingApp extends StatefulWidget {
  const KhmerShoppingApp({super.key});

  @override
  State<KhmerShoppingApp> createState() => _KhmerShoppingAppState();
}

class _KhmerShoppingAppState extends State<KhmerShoppingApp> {
  bool? _lastLight;

  /// Forces every widget to rebuild so colours read from [AppColors] update
  /// immediately when the theme changes (navigation state is preserved).
  void _rebuildAll() {
    if (!mounted) return;
    void rebuild(Element element) {
      element.markNeedsBuild();
      element.visitChildren(rebuild);
    }

    (context as Element).visitChildren(rebuild);
  }

  @override
  Widget build(BuildContext context) {
    final light = context.watch<ThemeProvider>().isLight;
    AppColors.isLight = light;

    if (_lastLight != null && _lastLight != light) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _rebuildAll());
    }
    _lastLight = light;

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: light ? Brightness.dark : Brightness.light,
        systemNavigationBarColor: AppColors.surface,
        systemNavigationBarIconBrightness:
            light ? Brightness.dark : Brightness.light,
      ),
    );

    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      navigatorKey: AppNavigator.key,
      theme: AppTheme.build(light),
      themeAnimationDuration: Duration.zero,
      home: const SplashScreen(),
    );
  }
}
