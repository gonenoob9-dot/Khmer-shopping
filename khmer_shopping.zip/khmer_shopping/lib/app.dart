import 'package:flutter/material.dart';

import 'package:khmer_shopping/core/app_navigator.dart';
import 'package:khmer_shopping/core/config.dart';
import 'package:khmer_shopping/core/theme.dart';
import 'package:khmer_shopping/screens/splash_screen.dart';

class KhmerShoppingApp extends StatelessWidget {
  const KhmerShoppingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      navigatorKey: AppNavigator.key,
      theme: AppTheme.dark,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      home: const SplashScreen(),
    );
  }
}
