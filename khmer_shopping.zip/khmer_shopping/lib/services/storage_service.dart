import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'package:khmer_shopping/models/order.dart';
import 'package:khmer_shopping/models/user_profile.dart';

/// Thin wrapper around SharedPreferences. All persistence goes through here.
class StorageService {
  StorageService._(this._prefs);

  final SharedPreferences _prefs;

  static Future<StorageService> create() async {
    final prefs = await SharedPreferences.getInstance();
    return StorageService._(prefs);
  }

  static const String _cartKey = 'cart_v1';
  static const String _favoritesKey = 'favorites_v1';
  static const String _ordersKey = 'orders_v1';
  static const String _profileKey = 'profile_v1';
  static const String _notificationsKey = 'notifications_v1';
  static const String _recentSearchesKey = 'recent_searches_v1';
  static const String _lightModeKey = 'light_mode_v1';

  // ---- Cart (product id -> quantity, insertion ordered) ----
  Map<String, int> readCart() {
    final raw = _prefs.getString(_cartKey);
    if (raw == null) return {};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      return decoded.map((k, v) => MapEntry(k, (v as num).toInt()));
    } catch (_) {
      return {};
    }
  }

  Future<void> writeCart(Map<String, int> cart) =>
      _prefs.setString(_cartKey, jsonEncode(cart));

  // ---- Favorites ----
  List<String> readFavorites() => _prefs.getStringList(_favoritesKey) ?? [];

  Future<void> writeFavorites(List<String> ids) =>
      _prefs.setStringList(_favoritesKey, ids);

  // ---- Orders ----
  List<Order> readOrders() {
    final raw = _prefs.getString(_ordersKey);
    if (raw == null) return [];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((e) => Order.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> writeOrders(List<Order> orders) => _prefs.setString(
        _ordersKey,
        jsonEncode(orders.map((o) => o.toJson()).toList()),
      );

  // ---- Profile ----
  UserProfile readProfile() {
    final raw = _prefs.getString(_profileKey);
    if (raw == null) return const UserProfile();
    try {
      return UserProfile.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return const UserProfile();
    }
  }

  Future<void> writeProfile(UserProfile profile) =>
      _prefs.setString(_profileKey, jsonEncode(profile.toJson()));

  // ---- Settings ----
  bool readNotifications() => _prefs.getBool(_notificationsKey) ?? true;

  Future<void> writeNotifications(bool value) =>
      _prefs.setBool(_notificationsKey, value);

  List<String> readRecentSearches() =>
      _prefs.getStringList(_recentSearchesKey) ?? [];

  Future<void> writeRecentSearches(List<String> searches) =>
      _prefs.setStringList(_recentSearchesKey, searches);

  bool readLightMode() => _prefs.getBool(_lightModeKey) ?? false;

  Future<void> writeLightMode(bool value) =>
      _prefs.setBool(_lightModeKey, value);

  Future<void> clearAll() => _prefs.clear();
}
